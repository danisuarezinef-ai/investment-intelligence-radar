import hashlib,json,os,re,shutil,subprocess,tempfile,time
from pathlib import Path
V='1.2.1-dev21-official-update-channel'
OLD={'ceo_core/in_app_updater.py':'8b50cc09d1e40bc453e003a7dd429c446d4bbf0602f2ce8dd18db59449a7567d','scripts/ceo_stdlib_work_mode.py':'99341e48d6b9fc1a3729492e86a55b931dec2d5bd6162f5148b54fe7f548be5c'}
ROOT=Path(__file__).resolve().parents[1]; STATUS=ROOT/'CEO_DEV21_BOOTSTRAP_STATUS.json'
def data(): return Path(os.getenv('LOCALAPPDATA') or Path.home()/'AppData'/'Local')/'CEO de IAs'
def stat(s,**x):
 try: STATUS.write_text(json.dumps({'status':s,'version':V,'at':time.strftime('%Y-%m-%dT%H:%M:%S'),**x},ensure_ascii=False,indent=2),encoding='utf-8')
 except: pass
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def candidates():
 seen=set(); roots=[data()/'updates'/'versions',Path.home()/'Desktop',Path.home()/'Downloads',Path.home()/'Documents']
 for base in roots:
  if not base.exists(): continue
  for p in base.rglob('ceo_stdlib_work_mode.py'):
   if any(z in p.parts for z in ('.git','__pycache__','.venv','venv')): continue
   r=p.parent.parent
   if r in seen: continue
   seen.add(r)
   try:
    if all((r/f).is_file() and sha(r/f)==h for f,h in OLD.items()): yield r
   except: pass
def apply(root,patch):
 lines=patch.splitlines(True); i=0
 while i<len(lines):
  if not lines[i].startswith('--- a/'): i+=1; continue
  rel=lines[i+1][6:].strip(); i+=2; src=(root/rel).read_text(encoding='utf-8').splitlines(True); out=[]; pos=0
  while i<len(lines) and not lines[i].startswith('--- a/'):
   if not lines[i].startswith('@@'): i+=1; continue
   m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]); old=int(m.group(1))-1; out+=src[pos:old]; pos=old; i+=1
   while i<len(lines) and not lines[i].startswith('@@') and not lines[i].startswith('--- a/'):
    x=lines[i]; tag=x[:1]
    if tag==' ': out.append(src[pos]); pos+=1
    elif tag=='-': pos+=1
    elif tag=='+': out.append(x[1:])
    elif tag=='\\': pass
    i+=1
  out+=src[pos:]; (root/rel).write_text(''.join(out),encoding='utf-8')
def main():
 try:
  stat('LOCATING_DEV20'); old=next(candidates(),None)
  if not old: raise RuntimeError('No se encontro la instalacion DEV20 exacta para actualizar sin riesgo')
  versions=data()/'updates'/'versions'; versions.mkdir(parents=True,exist_ok=True); full=versions/(V+'-full')
  if full.exists(): shutil.rmtree(full,ignore_errors=True)
  tmp=Path(tempfile.mkdtemp(prefix='dev21-',dir=str(versions))); shutil.copytree(old,tmp/'full',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.git','.venv'))
  fulltmp=tmp/'full'; apply(fulltmp,(ROOT/'dev21.patch').read_text(encoding='utf-8'))
  # verify DEV21 markers before activation
  wm=(fulltmp/'scripts/ceo_stdlib_work_mode.py').read_text(encoding='utf-8'); up=(fulltmp/'ceo_core/in_app_updater.py').read_text(encoding='utf-8')
  if V not in wm or 'OFFICIAL_MANIFEST_URL' not in up or 'base64-chunks' not in up: raise RuntimeError('Verificacion DEV21 fallida')
  fulltmp.rename(full); shutil.rmtree(tmp,ignore_errors=True)
  ptr=data()/'updates'/'current.json'; q={'version':V,'root':str(full),'launcher':'ABRIR_CEO.cmd','human_confirmed':True,'automatic_promotion':False,'activated_at':time.strftime('%Y-%m-%dT%H:%M:%S')}; t=ptr.with_suffix('.tmp'); t.write_text(json.dumps(q,ensure_ascii=False,indent=2),encoding='utf-8'); t.replace(ptr)
  stat('PASS',source=str(old),root=str(full),automatic_promotion=False)
  if os.name=='nt': subprocess.Popen([os.getenv('COMSPEC') or 'cmd.exe','/d','/c','start','',str(full/'ABRIR_CEO.cmd')],cwd=str(full))
  return 0
 except Exception as e: stat('BLOCKED',error=f'{type(e).__name__}: {e}'); print('[BLOCKED]',e); return 6
if __name__=='__main__': raise SystemExit(main())
