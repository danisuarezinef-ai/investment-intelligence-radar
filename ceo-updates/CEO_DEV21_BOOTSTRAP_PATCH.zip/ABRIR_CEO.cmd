@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1 && (py -3 -u scripts\bootstrap_dev21.py & goto done)
where python >nul 2>&1 && (python -u scripts\bootstrap_dev21.py & goto done)
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" ("%LocalAppData%\Programs\Python\Python312\python.exe" -u scripts\bootstrap_dev21.py & goto done)
echo [BLOCKED] Python no encontrado.& set RC=6& goto end
:done
set RC=%ERRORLEVEL%
:end
if not "%RC%"=="0" pause
exit /b %RC%
