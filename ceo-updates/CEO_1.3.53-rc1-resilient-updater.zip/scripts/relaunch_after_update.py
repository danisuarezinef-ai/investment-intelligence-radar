from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ceo_core.in_app_updater import InAppUpdater  # noqa: E402


def pid_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            cp = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True, timeout=5)
            return str(pid) in cp.stdout
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _launch(launcher: Path, *, log_path: Path | None = None) -> subprocess.Popen:
    if not launcher.is_file():
        raise FileNotFoundError(str(launcher))
    log_handle = None
    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_handle = log_path.open("ab", buffering=0)
    kwargs = {
        "cwd": str(launcher.parent),
        "stdout": log_handle if log_handle is not None else subprocess.DEVNULL,
        "stderr": subprocess.STDOUT if log_handle is not None else subprocess.DEVNULL,
    }
    if os.name == "nt":
        comspec = os.environ.get("COMSPEC") or "cmd.exe"
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.Popen(
            [comspec, "/d", "/s", "/c", f'call "{launcher}"'],
            creationflags=flags,
            **kwargs,
        )
        if log_handle is not None:
            setattr(proc, "_ceo_log_handle", log_handle)
        return proc
    if launcher.suffix.lower() in {".sh", ".bash"}:
        proc = subprocess.Popen(["bash", str(launcher)], start_new_session=True, **kwargs)
    else:
        proc = subprocess.Popen([str(launcher)], start_new_session=True, **kwargs)
    if log_handle is not None:
        setattr(proc, "_ceo_log_handle", log_handle)
    return proc


def _terminate_tree(proc: subprocess.Popen | None) -> None:
    if proc is None or proc.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=10)
            return
        except Exception:
            pass
    try:
        proc.terminate()
        proc.wait(timeout=5)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _status_url(root: Path, *, not_before: float) -> str | None:
    path = root / "CEO_REAL_WORK_INTERFACE_STATUS.json"
    try:
        stat = path.stat()
        if stat.st_mtime + 0.01 < not_before:
            return None
        row = json.loads(path.read_text(encoding="utf-8"))
        if row.get("status") != "PASS":
            return None
        url = str(row.get("url") or "").strip()
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"}:
            return None
        return url.rstrip("/")
    except Exception:
        return None



def _write_restart_progress(updater: InAppUpdater, phase: str, **fields) -> None:
    try:
        InAppUpdater._atomic_json(updater.root / "restart-progress.json", {
            "phase": phase,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "updated_at_epoch": time.time(),
            **fields,
        })
    except Exception:
        pass

def supervise_activation(
    *,
    updater: InAppUpdater,
    version: str,
    activation_id: str,
    launcher: Path,
    fallback_launcher: Path,
    wait_pid: int = 0,
    health_timeout: float = 60.0,
) -> dict:
    _write_restart_progress(updater, "waiting_old_process", version=version, percent=10)
    deadline = time.time() + 45
    while wait_pid and time.time() < deadline and pid_exists(wait_pid):
        time.sleep(0.35)

    pointer = updater.current_pointer() or {}
    if str(pointer.get("version") or "") != version or str(pointer.get("activation_id") or "") != activation_id:
        raise RuntimeError("El puntero de activación cambió antes del reinicio")
    root = Path(str(pointer.get("root") or launcher.parent)).resolve()
    health_path = str(pointer.get("health_path") or "/api/health")
    if not health_path.startswith("/"):
        health_path = "/api/health"

    started_at = time.time()
    proc: subprocess.Popen | None = None
    last_error = "new version did not become healthy"
    try:
        child_log = updater.root / "restart-child-latest.log"
        _write_restart_progress(updater, "launching_new_version", version=version, percent=35, launcher=str(launcher), log=str(child_log))
        proc = _launch(launcher, log_path=child_log)
        deadline = time.time() + max(5.0, health_timeout)
        _write_restart_progress(updater, "health_check", version=version, percent=55, pid=proc.pid, log=str(child_log))
        while time.time() < deadline:
            if proc.poll() is not None:
                last_error = f"new version exited early with code {proc.returncode}"
                break
            base = _status_url(root, not_before=started_at)
            if base:
                try:
                    health = updater.verify_health_url(
                        base + health_path,
                        expected_version=version,
                        activation_id=activation_id,
                        timeout=3.0,
                    )
                    confirmed = updater.confirm_health(version, activation_id=activation_id, health=health)
                    _write_restart_progress(updater, "healthy", version=version, percent=100, pid=proc.pid, url=base)
                    return {"ok": True, "confirmed": confirmed, "url": base, "pid": proc.pid}
                except Exception as exc:
                    last_error = f"{type(exc).__name__}: {exc}"
            time.sleep(0.4)
    except Exception as exc:
        last_error = f"{type(exc).__name__}: {exc}"

    _terminate_tree(proc)
    _write_restart_progress(updater, "rollback", version=version, percent=80, reason=last_error)
    rollback = updater.rollback(reason=last_error, failed_version=version)
    previous_launcher = rollback.get("launcher_path")
    restart = Path(previous_launcher) if previous_launcher else fallback_launcher
    rollback_proc = None
    try:
        if restart.is_file():
            rollback_proc = _launch(restart)
    except Exception:
        pass
    _write_restart_progress(updater, "rolled_back", version=version, percent=100, reason=last_error, rollback_pid=getattr(rollback_proc, "pid", None))
    return {
        "ok": False,
        "rolled_back": True,
        "reason": last_error,
        "rollback": rollback,
        "rollback_pid": getattr(rollback_proc, "pid", None),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wait-pid", type=int, default=0)
    ap.add_argument("--launcher", required=True)
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--version", required=True)
    ap.add_argument("--activation-id", required=True)
    ap.add_argument("--fallback-launcher", required=True)
    ap.add_argument("--health-timeout", type=float, default=60.0)
    ns = ap.parse_args()

    updater = InAppUpdater(Path(ns.data_root))
    result = supervise_activation(
        updater=updater,
        version=ns.version,
        activation_id=ns.activation_id,
        launcher=Path(ns.launcher).resolve(),
        fallback_launcher=Path(ns.fallback_launcher).resolve(),
        wait_pid=ns.wait_pid,
        health_timeout=ns.health_timeout,
    )
    log = updater.root / "last-restart-supervision.json"
    try:
        InAppUpdater._atomic_json(log, result)
    except Exception:
        pass
    return 0 if result.get("ok") else 7


if __name__ == "__main__":
    raise SystemExit(main())
