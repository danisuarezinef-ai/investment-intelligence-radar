from __future__ import annotations
from dataclasses import asdict,dataclass
from .models import ProjectState
from .productive_truth_v2 import ProductiveTruthV2
from .recovery_churn_fuse_v2 import RecoveryChurnFuseV2
from .productive_fallback_orchestrator_v1 import ProductiveFallbackOrchestratorV1

@dataclass(slots=True)
class UsefulOutputWatchdogReport:
    status:str; stalled:bool; recoveries_without_progress:int; fuse_open:bool; fallback_action:str; repaired_units:int
    def to_dict(self):return asdict(self)

class UsefulOutputWatchdogV2:
    KEY='useful_output_watchdog_v2'
    def __init__(self):
        self.truth=ProductiveTruthV2(recovery_trip=4);self.fuse=RecoveryChurnFuseV2(max_attempts=4);self.fallback=ProductiveFallbackOrchestratorV1()
    def tick(self,state:ProjectState)->UsefulOutputWatchdogReport:
        truth=self.truth.assess(state)
        fuse=self.fuse.apply(state,attempts_without_progress=truth.worker_recoveries,stalled=truth.stalled)
        action='none';repaired=0
        # Trigger a real strategy change immediately when the fuse opens. Do not
        # manufacture another recovery wrapper.
        if fuse.open:
            fb=self.fallback.apply(state);action=fb.action;repaired=fb.rebuilt+fb.provider_deferred
            if repaired:
                state.metadata.pop('suppress_new_internal_recovery',None)
                state.metadata.pop('autonomy_stalled',None)
                state.metadata['productivity_kick_requested']=True
                state.metadata['operator_productivity_state']='REPLANIFICANDO'
            else:
                state.metadata['operator_productivity_state']='BLOQUEADO'
        elif truth.stalled:
            state.metadata['operator_productivity_state']='ATASCADO'
        elif truth.status=='working':
            state.metadata['operator_productivity_state']='TRABAJANDO'
        elif truth.status=='planning':
            state.metadata['operator_productivity_state']='PLANIFICANDO'
        else:
            state.metadata['operator_productivity_state']=truth.status.upper()
        out=UsefulOutputWatchdogReport(state.metadata['operator_productivity_state'],truth.stalled,truth.worker_recoveries,fuse.open,action,repaired)
        state.metadata[self.KEY]=out.to_dict();return out
