from __future__ import annotations

"""Dependency-light CEO Work Mode server.

This is a Windows resilience path for cases where FastAPI/Uvicorn are unavailable.
It deliberately uses only Python's stdlib for HTTP while reusing the existing CEO core.
No validation gates are re-run or bypassed.
"""

import asyncio
import getpass
import json
import os
import re
from pathlib import Path
import socket
import subprocess
import shutil
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
APP_VERSION = "1.3.52-rc1-executive-ux"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from ceo_core.startup_diagnostics import StartupDiagnostics

DIAGNOSTICS = StartupDiagnostics()
RESULTS = ROOT / "RESULTADOS_CEO"
RESULTS.mkdir(parents=True, exist_ok=True)
STATUS_PATH = ROOT / "CEO_REAL_WORK_INTERFACE_STATUS.json"
STATUS_COPY = RESULTS / "CEO_REAL_WORK_INTERFACE_STATUS.json"
FAILURE_PATH = ROOT / "CEO_STARTUP_FAILURE.txt"


def write_status(payload: dict[str, Any]) -> None:
    payload = dict(payload)
    payload.setdefault("production_verified", False)
    payload.setdefault("generated_at", time.strftime("%Y-%m-%dT%H:%M:%S"))
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
    for p in (STATUS_PATH, STATUS_COPY):
        try:
            p.write_text(text, encoding="utf-8")
        except Exception:
            pass
    try:
        DIAGNOSTICS.record(str(payload.get("status") or "UNKNOWN"), component="work-mode", **{k: v for k, v in payload.items() if k != "status"})
    except Exception:
        pass


def write_failure(exc: BaseException) -> None:
    text = f"{type(exc).__name__}: {exc}\n\n{traceback.format_exc()}"
    try:
        FAILURE_PATH.write_text(text, encoding="utf-8")
    except Exception:
        pass
    try:
        DIAGNOSTICS.exception(exc, component="work-mode")
    except Exception:
        pass
    write_status({"status": "BLOCKED", "error": str(exc), "diagnostic": str(FAILURE_PATH), "persistent_diagnostic": str(DIAGNOSTICS.latest_path)})


HTML = r'''<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CEO de IAs · Trabajo real</title><link rel="icon" href="/favicon.ico">
<style>
:root{font-family:Inter,Segoe UI,system-ui,sans-serif;background:#f3f5f8;color:#111827;--ink:#111827;--muted:#687386;--line:#e2e7ef;--soft:#f7f9fc;--blue:#2563eb;--cyan:#06b6d4;--violet:#7c3aed;--green:#15803d;--amber:#a16207;--red:#b42318}*{box-sizing:border-box}body{margin:0;background:linear-gradient(180deg,#eef3fa 0,#f7f8fb 220px,#f3f5f8 100%)}main{max-width:1180px;margin:auto;padding:20px 18px 60px}.top{display:flex;justify-content:space-between;gap:18px;align-items:center;margin-bottom:14px}.brand-wrap{display:flex;align-items:center;gap:11px}.brandmark{width:38px;height:38px;border-radius:12px;background:linear-gradient(145deg,#0f172a,#1e293b);position:relative;box-shadow:0 8px 25px rgba(15,23,42,.18)}.brandmark:before{content:"";position:absolute;inset:8px;border:4px solid #4de0ff;border-right-color:transparent;border-radius:50%}.brandmark:after{content:"";position:absolute;width:8px;height:8px;border-radius:50%;background:#8b5cf6;right:7px;top:7px}.brand{font-weight:900;letter-spacing:.11em}.version{font-size:11px;color:var(--muted);margin-top:2px}.status{font-size:13px;text-align:right}.status strong{display:inline-flex;align-items:center;padding:7px 11px;border-radius:999px;background:#fff;border:1px solid var(--line)}.status #provider{font-size:11px;color:var(--muted);margin-top:4px}.card{background:rgba(255,255,255,.94);border:1px solid var(--line);border-radius:20px;padding:18px;margin:12px 0;box-shadow:0 10px 35px rgba(35,48,73,.055)}.hero{padding:22px;background:linear-gradient(135deg,#fff 0,#f7fbff 65%,#f4f1ff 100%)}.hero-top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.eyebrow{font-size:11px;font-weight:800;letter-spacing:.13em;color:#526079;text-transform:uppercase}.goal-title{font-size:clamp(23px,3.5vw,38px);line-height:1.12;margin:7px 0 6px;max-width:830px}.goal-sub{color:var(--muted);font-size:13px}.state-chip{white-space:nowrap;font-size:12px;font-weight:800;border-radius:999px;padding:8px 11px;background:#e8f7ed;color:var(--green)}.executive-grid{display:grid;grid-template-columns:1.2fr repeat(3,1fr);gap:10px;margin-top:16px}.exec-metric{border:1px solid var(--line);background:#fff;border-radius:15px;padding:13px}.exec-metric b{display:block;font-size:24px;line-height:1}.exec-metric span{display:block;color:var(--muted);font-size:11px;margin-top:6px}.work-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}.workbox{background:var(--soft);border-radius:15px;padding:13px;min-height:105px}.workbox h3{font-size:13px;margin:0 0 8px}.section-head{display:flex;justify-content:space-between;gap:12px;align-items:center}h1{font-size:clamp(26px,4.5vw,44px);margin:8px 0 12px;line-height:1.06}h2{font-size:16px;margin:0 0 4px}.def{color:var(--muted);font-size:12px;margin-bottom:11px}textarea,input,select{width:100%;border:1px solid #d7dde7;border-radius:12px;padding:11px;font:inherit;background:#fff}textarea{min-height:105px;resize:vertical}.row{display:flex;gap:9px;align-items:center;flex-wrap:wrap}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:9px}.metric{background:var(--soft);border-radius:13px;padding:12px}.metric b{display:block;font-size:22px}.metric span{font-size:11px;color:var(--muted)}button{border:0;border-radius:11px;padding:10px 15px;background:#111827;color:#fff;cursor:pointer;font-weight:700}button:hover{filter:brightness(1.06)}button:disabled{opacity:.5;cursor:default}button.secondary{background:#edf1f6;color:#1f2937}.safety{display:flex;gap:7px;flex-wrap:wrap}.pill{background:#edf7ef;border-radius:999px;padding:6px 10px;font-size:11px}.warn{background:#fff3d8}.queue{display:grid;gap:7px}.task{padding:9px 11px;background:var(--soft);border-radius:11px;display:flex;justify-content:space-between;gap:12px}.small{font-size:12px;color:var(--muted)}.project{padding:9px 0;border-bottom:1px solid #eee}.project:last-child{border-bottom:0}.error{background:#fff0ec;padding:10px;border-radius:12px;white-space:pre-wrap}.ok{color:var(--green)}.waiting{color:var(--amber)}.secret{display:flex;gap:8px;align-items:center;margin-top:12px}.secret input{flex:1}.active-goal{margin-top:10px;padding:10px 12px;background:var(--soft);border-radius:12px}.active-goal strong{display:block;margin-bottom:4px}.banner{margin-top:13px;padding:11px 13px;border-radius:12px;font-weight:700;font-size:13px}.banner.okb{background:#e8f7ed;color:var(--green)}.banner.warnb{background:#fff4db;color:#815b00}.banner.errb{background:#fff0ec;color:#8f2d1f}.banner.infob{background:#eaf4ff;color:#1d4f91}.live{background:#e8f7ed!important;color:var(--green)!important}.updatebox{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center}.update-actions{display:flex;gap:8px;flex-wrap:wrap}.update-status{padding:12px;background:var(--soft);border-radius:12px}.update-status strong{display:block;margin-bottom:3px}.ops-list{display:grid;gap:7px}.ops-item{padding:9px 10px;background:#fff;border:1px solid var(--line);border-radius:10px}.ops-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px;background:#94a3b8}.ops-dot.working,.ops-dot.complete{background:#16a34a}.ops-dot.attention{background:#f59e0b}.ops-dot.planning{background:#3b82f6}.ops-dot.paused{background:#64748b}.ops-chart{width:100%;height:150px;background:#fff;border:1px solid var(--line);border-radius:10px;margin-top:8px}.ops-select{width:auto;min-width:150px;padding:7px 9px}.attention-card{background:#fff8e7;border:1px solid #eed69c;border-radius:12px;padding:12px;margin-top:8px}.attention-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}.danger{background:#a32920!important}.controlbar{display:grid;grid-template-columns:1fr 1fr;gap:10px}.controlbox{background:var(--soft);border-radius:14px;padding:12px}.compact-details{margin:12px 0;background:#fff;border:1px solid var(--line);border-radius:16px;overflow:hidden}.compact-details>summary{cursor:pointer;padding:14px 16px;font-weight:800;list-style:none}.compact-details>summary::-webkit-details-marker{display:none}.compact-details>summary:after{content:"＋";float:right;color:#64748b}.compact-details[open]>summary:after{content:"−"}.details-body{border-top:1px solid var(--line);padding:14px 16px}.tech-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.human-attn-badge{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:800}.human-attn-badge.ok{color:var(--green)}.human-attn-badge.warn{color:var(--amber)}@media(max-width:800px){.executive-grid{grid-template-columns:1fr 1fr}.work-grid,.tech-grid,.controlbar{grid-template-columns:1fr}.grid{grid-template-columns:1fr 1fr}.top{align-items:flex-start}.status{text-align:left}.hero-top{display:block}.state-chip{display:inline-block;margin-top:8px}}@media(max-width:520px){.executive-grid{grid-template-columns:1fr 1fr}.exec-metric b{font-size:20px}}
</style></head>
<body><main>
<div class="top"><div class="brand-wrap"><div class="brandmark" aria-hidden="true"></div><div><div class="brand">CEO DE IAs</div><div class="version">Executive UX · actualización continua</div></div></div><div class="status"><strong id="op">Cargando…</strong><div id="provider"></div></div></div>
<section class="card hero"><div class="hero-top"><div><div class="eyebrow">Goal Engine</div><div id="heroGoal" class="goal-title">Preparando CEO…</div><div class="goal-sub" id="heroSub">Objetivo, estado y siguiente acción en una sola vista.</div></div><span id="opsHealth" class="state-chip">Cargando…</span></div><div id="actionBanner" class="banner warnb">Comprobando estado operativo…</div><div class="executive-grid"><div class="exec-metric"><b id="progress">0%</b><span>Progreso del objetivo</span></div><div class="exec-metric"><b id="running">0</b><span>Workers activos</span></div><div class="exec-metric"><b id="opsEta">—</b><span>Tiempo estimado</span></div><div class="exec-metric"><b id="heroAttention">0</b><span>Decisiones tuyas</span></div></div><div class="work-grid"><div class="workbox"><h3>Ahora</h3><div id="opsCurrent" class="ops-list"><span class="small">Sin trabajo activo.</span></div></div><div class="workbox"><h3>Siguiente</h3><div id="opsNext" class="ops-list"><span class="small">Sin siguiente tarea.</span></div></div></div></section>
<section id="attentionSection" class="card" style="display:none"><div class="section-head"><div><h2>Necesita tu decisión</h2><div class="def">Sólo acciones que CEO no puede decidir por sí solo.</div></div><span id="humanAttentionBadge" class="human-attn-badge warn">Pendiente</span></div><div id="attentionCards"><span class="small">Sin decisiones humanas pendientes.</span></div></section>
<section class="card"><div class="section-head"><div><h2>Control</h2><div class="def">Lo esencial para dirigir el trabajo sin entrar en detalles técnicos.</div></div><button class="secondary" onclick="refreshAll()">Actualizar vista</button></div><div id="activeGoal" class="active-goal" style="display:none"></div><div class="controlbar" style="margin-top:10px"><div class="controlbox"><div class="row" style="justify-content:space-between"><span>Potencia</span><strong id="powerLabel">30%</strong></div><input id="power" type="range" min="1" max="100" value="30" oninput="powerLabel.textContent=this.value+'%'" onchange="savePower()"><div id="deviceDetail" class="small" style="margin-top:6px"></div></div><div class="controlbox"><div class="row" style="justify-content:space-between"><span>Estado de IA</span><span id="execPill" class="pill warn">Comprobando…</span></div><div id="geminiDetail" class="small" style="margin-top:8px">Gemini todavía no validado.</div><div id="keyBox" class="secret"><input id="sessionKey" type="password" autocomplete="off" spellcheck="false" placeholder="Gemini API key para esta sesión"><button onclick="activateGemini()">Activar</button></div></div></div><div class="row" style="margin-top:10px"><button class="secondary" onclick="pause()" id="pauseBtn">Pausar</button><span id="progressDetail" class="small"></span></div></section>
<details class="compact-details"><summary>Nuevo objetivo o proyecto</summary><div class="details-body"><h2>¿Qué quieres que consiga CEO?</h2><div class="def">CEO descompone, prioriza y continúa sin esperar “sigue”.</div><textarea id="goal" placeholder="Escribe un objetivo real…"></textarea><input id="name" placeholder="Nombre del proyecto (opcional)" style="margin-top:9px"><div class="row" style="margin-top:10px"><button onclick="start()" id="startBtn">Empezar proyecto</button></div></div></details>
<section class="card"><div class="section-head"><div><h2>Actualizaciones</h2><div class="def">Una sola acción: CEO descarga, verifica y prepara; tú confirmas la instalación.</div></div><button class="secondary" style="padding:7px 11px" onclick="toggleUpdateInfo()" title="Información avanzada">i</button></div><div class="updatebox"><div class="update-status"><strong id="updateHeadline">Comprobando actualizaciones…</strong><div id="updateDetail" class="small"></div></div><div class="update-actions"><button id="oneClickUpdateBtn" onclick="oneClickUpdate()" disabled>CEO está al día</button></div></div><div id="updateInfo" style="display:none;margin-top:10px"><div class="small" style="margin-bottom:8px">CEO verifica firma Ed25519, SHA-256, contrato y compatibilidad; conserva la versión anterior y puede volver atrás si la nueva no arranca correctamente.</div><input id="updateManifest" placeholder="Canal HTTPS de actualizaciones (manifest.json)"><div class="update-actions" style="margin-top:8px"><button class="secondary" onclick="saveUpdateChannel()">Guardar canal</button><button class="secondary" onclick="checkUpdate()">Comprobar ahora</button></div></div></section>
<details class="compact-details"><summary>Actividad técnica y evolución</summary><div class="details-body"><div class="executive-grid" style="grid-template-columns:repeat(3,1fr);margin-top:0"><div class="exec-metric"><b id="opsThroughput">—</b><span>tareas/h equivalentes</span></div><div class="exec-metric"><b id="opsTarget">—</b><span>workers objetivo</span></div><div class="exec-metric"><b id="done">0</b><span>completadas reales</span></div><div class="exec-metric"><b id="pending">0</b><span>pendientes reales</span></div><div class="exec-metric"><b id="opsRecoveries">0</b><span>recuperaciones</span></div><div class="exec-metric"><b id="opsCorrections">0</b><span>autocorrecciones</span></div></div><div class="tech-grid" style="margin-top:12px"><div><h2>Últimos eventos</h2><div id="opsTimeline" class="ops-list"><span class="small">Sin eventos todavía.</span></div><div id="opsAttention" class="small" style="margin-top:9px"></div></div><div><div class="row" style="justify-content:space-between"><h2>Evolución</h2><select id="opsMetric" class="ops-select" onchange="drawOpsChart(lastOps)"><option value="completed">Completadas</option><option value="failures">Fallos</option><option value="recoveries">Recuperaciones</option><option value="quality">Calidad</option></select></div><canvas id="opsChart" class="ops-chart" width="520" height="150"></canvas><div id="opsLedger" class="small" style="margin-top:6px"></div><div class="small" style="margin-top:6px">Reinicios automáticos: <strong id="opsRestarts">0</strong></div></div></div></div></details>
<details class="compact-details"><summary>Cola de trabajo</summary><div class="details-body"><div id="queue" class="queue"><span class="small">Sin cola todavía.</span></div></div></details>
<details class="compact-details"><summary>Seguridad</summary><div class="details-body"><div class="safety"><span class="pill">✓ Sin auto-promoción</span><span class="pill">✓ Git remoto bloqueado</span><span class="pill">✓ Sin compras automáticas</span><span class="pill">✓ Destructivas con gate humano</span></div></div></details>
<details class="compact-details"><summary>Proyectos</summary><div class="details-body"><div id="projects"><span class="small">Cargando…</span></div></div></details>
<details class="compact-details"><summary>Diagnóstico</summary><div class="details-body"><div id="diag" class="small">Interfaz activa.</div></div></details>
</main>
<script>
const $=id=>document.getElementById(id);let state=null;
async function j(url,opt){const r=await fetch(url,opt);const x=await r.json();if(!r.ok)throw new Error(x.error||('HTTP '+r.status));return x}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let draftDirty=false;
function fmtDuration(sec){sec=Number(sec||0);if(!isFinite(sec)||sec<=0)return '—';if(sec<60)return Math.round(sec)+' s';if(sec<3600)return Math.round(sec/60)+' min';const h=Math.floor(sec/3600),m=Math.round((sec%3600)/60);return h+' h '+m+' min'}
let lastOps=null;
let humanAttentionCount=0;
function drawOpsChart(o){o=o||lastOps||{};lastOps=o;const d=o.dashboard||{},metric=$('opsMetric')?.value||'completed',vals=(d.series||{})[metric]||[],c=$('opsChart');if(!c)return;const ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#deded8';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(30,10);ctx.lineTo(30,h-24);ctx.lineTo(w-8,h-24);ctx.stroke();const usable=vals.map(v=>v==null?null:+v),numbers=usable.filter(v=>v!=null&&Number.isFinite(v));if(!numbers.length){ctx.fillStyle='#777';ctx.font='12px Segoe UI';ctx.fillText('Sin datos suficientes',42,75);return}let min=Math.min(...numbers),max=Math.max(...numbers);if(metric!=='quality')min=Math.min(0,min);if(max===min)max=min+1;const x=i=>30+(w-42)*(i/Math.max(1,usable.length-1));const y=v=>(h-24)-((v-min)/(max-min))*(h-40);ctx.strokeStyle='#171717';ctx.lineWidth=2;ctx.beginPath();let started=false;usable.forEach((v,i)=>{if(v==null||!Number.isFinite(v)){started=false;return}const xx=x(i),yy=y(v);if(!started){ctx.moveTo(xx,yy);started=true}else ctx.lineTo(xx,yy)});ctx.stroke();ctx.fillStyle='#666';ctx.font='10px Segoe UI';ctx.fillText(String(max.toFixed(metric==='quality'?2:0)),2,14);ctx.fillText(String(min.toFixed(metric==='quality'?2:0)),2,h-24)}
function renderAttention(cards){cards=cards||[];humanAttentionCount=cards.length;const box=$('attentionCards'),section=$('attentionSection'),badge=$('humanAttentionBadge'),hero=$('heroAttention');if(hero)hero.textContent=String(cards.length);if(section)section.style.display=cards.length?'block':'none';if(badge){badge.textContent=cards.length?(cards.length+' pendiente'+(cards.length===1?'':'s')):'Sin decisiones';badge.className='human-attn-badge '+(cards.length?'warn':'ok')}if(!box)return;box.innerHTML=cards.length?cards.map(c=>`<div class="attention-card"><strong>${esc(c.title||'Decisión')}</strong><div class="small" style="margin-top:4px">${esc(c.body||'')}</div><div class="attention-actions"><button onclick="attentionAction('${esc(c.id)}','approve')">Aprobar</button><button class="secondary" onclick="attentionAction('${esc(c.id)}','postpone')">Posponer</button><button class="danger" onclick="attentionAction('${esc(c.id)}','reject')">Rechazar</button></div></div>`).join(''):'<span class="small">Sin decisiones humanas pendientes.</span>'}
async function attentionAction(id,action){if((action==='approve'||action==='reject')&&!confirm(action==='approve'?'¿Aprobar esta acción una sola vez?':'¿Rechazar esta acción?'))return;try{render(await j('/api/attention/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,action})}))}catch(e){$('diag').innerHTML='<div class="error">'+esc(e.message)+'</div>'}}
function eventLabel(kind){const m={provider_selected:'Proveedor seleccionado',provider_executing:'IA trabajando',provider_returned:'Resultado recibido',task_started:'Tarea iniciada',task_complete:'Tarea completada',verification_verdict:'Verificación independiente',recovery_started:'Recuperación automática',recovery_complete:'Recuperación completada',quality_retry:'Autocorrección',decision_created:'Decisión requerida'};return m[kind]||String(kind||'Evento').replaceAll('_',' ')}
function stageLabel(stage){const m={executing:'trabajando',returned:'resultado recibido',running:'trabajando',pending:'pendiente',retry:'reintentando',complete:'completada',completed:'completada',needs_review:'revisión'};return m[String(stage||'').toLowerCase()]||String(stage||'trabajando').replaceAll('_',' ')}
function renderObservability(o){o=o||{};lastOps=o;const h=o.health||{};const rawLevel=h.level||'idle';const level=(rawLevel==='attention'&&humanAttentionCount===0)?'planning':rawLevel;const labels={working:'TRABAJANDO',planning:(rawLevel==='attention'?'RECUPERANDO':'PLANIFICANDO'),attention:'TE NECESITA',complete:'COMPLETADO',paused:'PAUSADO',idle:'EN ESPERA'};const health=$('opsHealth');if(health){health.innerHTML='<span class="ops-dot '+esc(level)+'"></span>'+esc(labels[level]||String(level).toUpperCase());health.className='state-chip'}const tp=o.throughput||{};$('opsThroughput').textContent=tp.tasks_per_hour_equivalent==null?'—':tp.tasks_per_hour_equivalent;$('opsEta').textContent=fmtDuration(o.eta?.seconds);$('opsRestarts').textContent=o.scheduler?.auto_restarts??0;const rz=o.resilience||{};$('opsTarget').textContent=rz.adaptive_scheduler?.target??'—';$('opsRecoveries').textContent=rz.worker_recoveries??0;const gv=o.governance||{};$('opsCorrections').textContent=gv.self_corrections??0;const cur=o.current_work||[];$('opsCurrent').innerHTML=cur.length?cur.slice(0,3).map(x=>`<div class="ops-item"><strong>${esc(x.title)}</strong><div class="small">${esc(x.provider||'IA')} · ${esc(stageLabel(x.stage))} · ${fmtDuration(x.elapsed_seconds)}</div></div>`).join(''):'<span class="small">Sin trabajo productivo activo en este instante.</span>';const nx=o.next_work||[];$('opsNext').innerHTML=nx.length?nx.slice(0,3).map(x=>`<div class="ops-item"><strong>${esc(x.title)}</strong><div class="small">${esc(stageLabel(x.status))}${x.priority!=null?' · prioridad '+x.priority:''}</div></div>`).join(''):'<span class="small">CEO decidirá el siguiente paso cuando termine la tarea actual.</span>';const tl=o.timeline||[];$('opsTimeline').innerHTML=tl.length?tl.slice(0,8).map(x=>`<div class="ops-item"><strong>${esc(eventLabel(x.kind))}</strong><div class="small">${esc(x.title||'')}${x.provider?' · '+esc(x.provider):''}</div>${x.detail?`<div class="small">${esc(x.detail)}</div>`:''}</div>`).join(''):'<span class="small">Sin eventos todavía.</span>';const att=o.attention||[],stale=o.stale_workers||[];const dh=gv.dependency_health||{};const depIssues=(dh.missing||0)+(dh.failed_hard||0)+(dh.cycles||0);const automaticIssues=att.length+stale.length+depIssues;const attBox=$('opsAttention');if(humanAttentionCount>0){attBox.textContent='Hay '+humanAttentionCount+' decisión(es) que requieren tu intervención.'}else if(automaticIssues>0||rawLevel==='attention'){attBox.textContent='CEO está resolviendo '+Math.max(1,automaticIssues)+' incidencia(s) automáticamente. No requiere acción tuya ahora.'}else{attBox.textContent='Sin incidencias activas.'}const led=o.evidence_ledger||{};$('opsLedger').textContent='Registro de evidencia: '+(led.valid===false?'integridad comprometida':'integridad correcta')+' · '+(led.entries??0)+' eventos';drawOpsChart(o)}
$('goal').addEventListener('input',()=>{draftDirty=true});
$('name').addEventListener('input',()=>{draftDirty=true});
function render(s){
state=s;const live=!!s.execution_enabled;const real=s.operational_status||'SIN PROYECTO';const schedulerAlive=!!s.scheduler_alive;
const working=!!(s.active&&live&&schedulerAlive&&['TRABAJANDO','PLANIFICANDO','VERIFICANDO','CORRIGIENDO'].includes(real));
$('op').textContent=s.active?real:'SIN PROYECTO';$('op').style.color=working?'#176d2d':(['BLOQUEADO','SIN SCHEDULER'].includes(real)?'#8b2f1f':'#7a5600');
$('provider').textContent=(live?'IA conectada':'IA no activa')+(schedulerAlive?' · motor activo':' · motor detenido');
$('execPill').textContent=live?'✓ Gemini VALIDADO y activo':'⚠ Gemini NO activo';$('execPill').className='pill '+(live?'live':'warn');$('keyBox').style.display=live?'none':'flex';
$('geminiDetail').textContent=live?('Conexión Gemini verificada'+(s.gemini_model?' · modelo '+s.gemini_model:'')+'.'):('Sin validación Gemini. CEO no ejecutará trabajo IA.');
$('progress').textContent=(s.metrics?.progress??0)+'%';$('running').textContent=s.metrics?.running??0;$('done').textContent=s.metrics?.completed??0;$('pending').textContent=s.metrics?.pending??0;const bp=s.metrics?.batch_progress??0;const cr=s.metrics?.control_running??0;const cp=s.metrics?.control_pending??0;const cc=s.metrics?.control_completed??0;const last=s.metrics?.last_productive_progress_at||'todavía sin avance productivo registrado';$('progressDetail').textContent='Lote conocido: '+bp+'% · control interno: '+cr+' ejecutando, '+cp+' pendiente(s), '+cc+' completada(s) · último avance real: '+last;const dp=s.device_fabric?.plan?.changes||[];const nt=s.device_fabric?.notification_target||{};$('deviceDetail').textContent='Reparto por dispositivo activo. Potencia '+(s.power_percent??30)+'% · cambios de asignación en este balance: '+dp.length+' · notificaciones de decisión fijadas al móvil'+(nt.device_id?' ('+nt.device_id+')':' cuando esté conectado')+'.';
renderAttention(s.attention_cards||[]);renderObservability(s.observability);
$('power').value=s.power_percent??30;$('powerLabel').textContent=$('power').value+'%';$('pauseBtn').textContent=s.paused?'Reanudar':'Pausar';$('startBtn').disabled=!live;$('startBtn').title=live?'Iniciar trabajo real':'Primero activa y valida Gemini';
if(s.active&&s.goal){$('activeGoal').style.display='block';$('activeGoal').innerHTML='<strong>Objetivo activo</strong><div class="small">'+esc(s.goal)+'</div>'}else{$('activeGoal').style.display='none'}
const heroGoal=$('heroGoal'),heroSub=$('heroSub');if(heroGoal)heroGoal.textContent=(s.active&&s.goal)?s.goal:'Sin objetivo activo';if(heroSub)heroSub.textContent=s.active?('CEO continúa de forma autónoma · '+real):'Crea o reanuda un proyecto para empezar.';
const q=s.queue||[];$('queue').innerHTML=q.length?q.map(t=>`<div class="task"><div><strong>${esc(t.title)}</strong><div class="small">${esc(t.status)} · prioridad ${t.priority??0}${(t.dependencies||[]).length?' · deps '+t.dependencies.length:''}</div></div><span class="small">${esc(t.provider||'')}</span></div>`).join(''):'<span class="small">No hay tareas en cola.</span>';
if(working){$('actionBanner').className='banner okb';$('actionBanner').textContent='✓ CEO está trabajando con Gemini. Estado real: '+real+'.'}
else if(s.active&&s.paused){$('actionBanner').className='banner warnb';$('actionBanner').textContent='Proyecto PAUSADO; no está ejecutando tareas.'}
else if(!live){$('actionBanner').className='banner warnb';$('actionBanner').textContent='Gemini no está activo. CEO no está trabajando.'}
else if(s.active&&real==='NECESITA DECISIÓN'){$('actionBanner').className='banner errb';$('actionBanner').textContent='✗ Hay una tarea humana en NEEDS_REVIEW. Si es una auditoría interna de continuidad, CEO debe recuperarla solo; no requiere tu decisión. En DEV15 esas auditorías son atómicas y no deben quedar aquí.'}
else if(s.active&&real==='BLOQUEADO'){const bs=s.autonomy_stalled?.blockers||[];const blocked=(s.queue||[]).filter(t=>['blocked','failed','needs_review'].includes(t.status)).slice(0,3).map(t=>t.title+' ['+t.status+']');const why=(bs.length?bs:blocked);$('actionBanner').className='banner errb';$('actionBanner').textContent='✗ CEO está BLOQUEADO.'+(why.length?' Causa: '+why.join(' · '):' El watchdog no encontró una ruta ejecutable.')}
else if(s.goal_audit_rejection||s.goal_audit_invalidated){$('actionBanner').className='banner warnb';$('actionBanner').textContent='⚠ Cierre rechazado por evidencia insuficiente. CEO debe continuar hasta reunir prueba independiente.'}
else if(s.active&&real==='COMPLETADO'){$('actionBanner').className='banner okb';$('actionBanner').textContent='✓ Objetivo completado con evidencia independiente y auditoría estricta.'}
else if(s.field_endurance_required&&!s.field_endurance_certified){$('actionBanner').className='banner infob';$('actionBanner').textContent='ℹ Certificación desatendida pendiente: es una prueba posterior de resistencia en Windows. Solo impide declarar el objetivo FINALMENTE completado; no debe detener el trabajo actual.'}
else if(s.active){$('actionBanner').className='banner warnb';$('actionBanner').textContent='⚠ CEO no tiene trabajo ejecutándose ahora: '+real+'. El watchdog debe replanificar si el objetivo sigue incompleto.'}
else{$('actionBanner').className='banner okb';$('actionBanner').textContent='✓ Gemini activo. Ya puedes iniciar un proyecto real.'}
const wd=s.watchdog?.status?(' · watchdog '+s.watchdog.status):'';const gen=s.goal_continuity_generation?(' · ciclos de continuidad '+s.goal_continuity_generation):'';const sup=(s.metrics?.superseded??0)?(' · supersedidas '+s.metrics.superseded):'';const dup=s.continuity_duplicate_spawn_drops?(' · follow-ups duplicados descartados '+s.continuity_duplicate_spawn_drops):'';
const stall=s.autonomy_stalled?(' · bloqueo '+esc(JSON.stringify(s.autonomy_stalled).slice(0,700))):'';$('diag').textContent=(s.message||'Servidor local activo.')+wd+gen+sup+dup+(s.scheduler_error?' · '+s.scheduler_error:'')+stall;
}
async function refresh(){try{render(await j('/api/state'))}catch(e){$('diag').innerHTML='<div class="error">'+esc(e.message)+'</div>'}}
let updateState=null;
function toggleUpdateInfo(){const x=$('updateInfo');x.style.display=x.style.display==='none'?'block':'none'}
function setUpdateButton(label,enabled,version=''){const b=$('oneClickUpdateBtn');b.textContent=label;b.disabled=!enabled;if(version)b.dataset.version=version;else delete b.dataset.version}
async function updateStatus(remote=false){try{const u=await j('/api/update/status'+(remote?'?remote=1':''));updateState=u;$('updateManifest').value=u.manifest_url||$('updateManifest').value||'';const installable=(u.staged||[]).find(x=>!x.installed);if(u.error){$('updateHeadline').textContent='No se pudo comprobar la actualización';$('updateDetail').textContent=u.error;setUpdateButton('Reintentar comprobación',true)}else if(installable){$('updateHeadline').textContent='Actualización lista para instalar';$('updateDetail').textContent=installable.version+' ya está descargada y verificada.';setUpdateButton('Instalar y reiniciar',true,installable.version)}else if(u.available){$('updateHeadline').textContent='Nueva versión disponible';$('updateDetail').textContent=(u.remote.notes||u.remote.version)+' · versión actual '+u.current_version;setUpdateButton('Actualizar CEO',true,u.remote.version)}else if(!u.configured){$('updateHeadline').textContent='Canal de actualización no disponible';$('updateDetail').textContent='Abre la información (i) sólo si necesitas configurar el canal manualmente.';setUpdateButton('Comprobar de nuevo',true)}else if(remote){$('updateHeadline').textContent='CEO está al día';$('updateDetail').textContent='Versión '+u.current_version;setUpdateButton('CEO está al día',false)}else{$('updateHeadline').textContent='Actualizaciones preparadas';$('updateDetail').textContent='CEO comprobará el canal automáticamente.';setUpdateButton('Comprobar ahora',true)}return u}catch(e){$('updateHeadline').textContent='Error al comprobar actualizaciones';$('updateDetail').textContent=e.message;setUpdateButton('Reintentar',true);return null}}
async function saveUpdateChannel(){const url=$('updateManifest').value.trim();try{await j('/api/update/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({manifest_url:url,channel:'stable',auto_check:true})});$('updateHeadline').textContent='Canal guardado';$('updateDetail').textContent='Comprobando canal…';await updateStatus(true)}catch(e){$('updateDetail').textContent=e.message}}
async function checkUpdate(){setUpdateButton('Comprobando…',false);$('updateHeadline').textContent='Comprobando actualizaciones…';await updateStatus(true)}
async function oneClickUpdate(){const b=$('oneClickUpdateBtn');if(!updateState||(!updateState.available&&!(updateState.staged||[]).some(x=>!x.installed))){return checkUpdate()}try{let installable=(updateState.staged||[]).find(x=>!x.installed);if(!installable){setUpdateButton('Descargando y verificando…',false);$('updateHeadline').textContent='Preparando actualización…';$('updateDetail').textContent='CEO comprueba firma, integridad y compatibilidad. La versión actual sigue intacta.';const r=await j('/api/update/stage',{method:'POST'});if(r.available===false){return await updateStatus(true)}await updateStatus(false);installable=(updateState?.staged||[]).find(x=>!x.installed)}if(!installable)throw new Error('La actualización no quedó preparada para instalar.');const version=installable.version;const ok=confirm('CEO '+version+' está verificado y listo.\n\n¿Instalar y reiniciar ahora?\n\nSi la nueva versión no supera la comprobación de salud, CEO intentará volver automáticamente a la versión anterior.');if(!ok){$('updateHeadline').textContent='Actualización preparada';$('updateDetail').textContent='Queda lista. Puedes instalarla cuando quieras con el mismo botón.';setUpdateButton('Instalar y reiniciar',true,version);return}setUpdateButton('Instalando…',false);$('updateHeadline').textContent='Instalando '+version+'…';$('updateDetail').textContent='CEO se reiniciará y comprobará automáticamente que la nueva versión está sana.';await j('/api/update/install',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({version,confirm:true})})}catch(e){$('updateHeadline').textContent='No se pudo actualizar';$('updateDetail').textContent=e.message;setUpdateButton('Reintentar actualización',true);await updateStatus(false)}}
async function projects(){try{const a=await j('/api/projects');$('projects').innerHTML=a.length?a.map(p=>`<div class="project"><div class="row" style="justify-content:space-between"><div><strong>${esc(p.name||p.goal||'Proyecto')}</strong><div class="small">avance ${p.progress??0}% · lote ${p.batch_progress??0}% · ${p.productive_completed??0} completadas reales${p.active?' · activo':''}${p.paused?' · pausado':''}${p.portfolio?(' · cartera #'+p.portfolio.rank+' · '+p.portfolio.slots+' slot'+(p.portfolio.slots===1?'':'s')):''}</div></div>${p.active?'':`<button class="secondary" onclick="activateProject('${esc(p.id)}')">Reanudar este proyecto</button>`}</div></div>`).join(''):'<span class="small">No hay proyectos.</span>'}catch(e){}}
async function activateProject(id){try{$('actionBanner').className='banner warnb';$('actionBanner').textContent='Cambiando al proyecto seleccionado…';const s=await j('/api/project/activate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({project_id:id})});render(s);projects()}catch(e){$('diag').innerHTML='<div class="error">'+esc(e.message)+'</div>'}}
async function start(){const goal=$('goal').value.trim();const name=$('name').value.trim()||null;if(!state?.execution_enabled){$('actionBanner').className='banner errb';$('actionBanner').textContent='No iniciado: primero activa y valida Gemini.';return}if(goal.length<3){$('diag').innerHTML='<div class="error">Escribe un objetivo de al menos 3 caracteres.</div>';return}try{$('startBtn').disabled=true;$('actionBanner').className='banner warnb';$('actionBanner').textContent='Iniciando proyecto y scheduler…';const s=await j('/api/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({goal,name,power_percent:+$('power').value})});draftDirty=false;$('goal').value='';$('name').value='';render(s);projects()}catch(e){$('startBtn').disabled=false;$('actionBanner').className='banner errb';$('actionBanner').textContent='No se pudo iniciar: '+e.message;$('diag').innerHTML='<div class="error">'+esc(e.message)+'</div>'}}
async function pause(){try{render(await j(state?.paused?'/api/resume':'/api/pause',{method:'POST'}))}catch(e){}}
async function savePower(){try{render(await j('/api/power',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({power_percent:+$('power').value})}))}catch(e){}}
async function activateGemini(){const key=$('sessionKey').value.trim();if(!key){$('geminiDetail').textContent='Pega la clave Gemini en el campo de sesión.';return}try{$('geminiDetail').textContent='Validando la clave con Gemini…';const s=await j('/api/session-key',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})});$('sessionKey').value='';render(s);$('geminiDetail').textContent='✓ Gemini validado y activo'+(s.gemini_model?' · '+s.gemini_model:'')+'.'}catch(e){$('geminiDetail').textContent='✗ Gemini NO activado: '+e.message;$('diag').innerHTML='<div class="error">'+esc(e.message)+'</div>'}}
async function refreshAll(){await refresh();await projects()}setInterval(refresh,1200);refreshAll();updateStatus(false).then(u=>{if(u&&u.configured&&u.auto_check)setTimeout(()=>updateStatus(true),1200)});setInterval(()=>{if(updateState?.configured&&updateState?.auto_check)updateStatus(true)},6*60*60*1000);
</script></body></html>'''


class CEOEngine:
    def __init__(self, gemini_key: str | None):
        # Core imports are intentionally delayed so startup failures are always logged
        # next to the launcher, even if a dependency is missing.
        from ceo_core.ai_worker import AIWorkerProvider
        from ceo_core.decomposer import TaskDecomposer
        from ceo_core.goal_engine import GoalEngine
        from ceo_core.goal_completion_gate import GoalCompletionGate
        from ceo_core.graph import TaskGraph
        from ceo_core.planning import BaselineTaskPlanner
        from ceo_core.project_catalog import ProjectCatalog
        from ceo_core.providers.gemini_interactions import GeminiInteractionsTransport
        from ceo_core.real_work_queue import RealWorkQueue
        from ceo_core.progress_tracker import StableProgressTracker
        from ceo_core.device_fabric import AdaptiveDeviceFabric
        from ceo_core.in_app_updater import InAppUpdater
        from ceo_core.observability import OperationalObservability
        from ceo_core.operator_attention import OperatorAttentionBroker
        from ceo_core.remote_control import RemoteControlProtocol, load_or_create_remote_secret
        from ceo_core.remote_session_v2 import RemoteSessionGuardV2
        from ceo_core.routing import MultiProviderRouter
        from ceo_core.runtime import user_data_root
        from ceo_core.scheduler import ContinuousScheduler

        self.TaskDecomposer = TaskDecomposer
        self.GoalEngine = GoalEngine
        self.GoalCompletionGate = GoalCompletionGate
        self.goal_completion_gate = GoalCompletionGate()
        self.Graph = TaskGraph
        self.BaselineTaskPlanner = BaselineTaskPlanner
        self.ProjectCatalog = ProjectCatalog
        self.RealWorkQueue = RealWorkQueue
        self.StableProgressTracker = StableProgressTracker
        self.AdaptiveDeviceFabric = AdaptiveDeviceFabric
        self.InAppUpdater = InAppUpdater
        self.OperationalObservability = OperationalObservability
        self.OperatorAttentionBroker = OperatorAttentionBroker
        self.RemoteControlProtocol = RemoteControlProtocol
        self.RemoteSessionGuardV2 = RemoteSessionGuardV2
        self.MultiProviderRouter = MultiProviderRouter
        self.ContinuousScheduler = ContinuousScheduler
        self.AIWorkerProvider = AIWorkerProvider
        self.GeminiInteractionsTransport = GeminiInteractionsTransport
        self.data_dir = user_data_root()
        self.projects = ProjectCatalog(self.data_dir / "projects")
        self.progress_tracker = StableProgressTracker()
        self.device_fabric = AdaptiveDeviceFabric()
        self.updater = InAppUpdater(self.data_dir)
        self.observability = OperationalObservability()
        self.attention_broker = OperatorAttentionBroker()
        self.remote_protocol = RemoteControlProtocol(load_or_create_remote_secret(self.data_dir))
        self.remote_session_guard = RemoteSessionGuardV2()
        # A key is never enough to claim execution is available. Keep it pending
        # until a real generateContent probe succeeds. This prevents a malformed,
        # revoked, quota-blocked or offline key from creating a false ACTIVE state.
        self._pending_gemini_key = (gemini_key or "").strip() or None
        self.gemini_key = None
        self.execution_enabled = False
        self.provider_mode = "gemini-key-pending-validation" if self._pending_gemini_key else "plan-only (sin Gemini)"
        self.gemini_model = None
        self.gemini_validation_error = None
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run_loop, name="ceo-stdlib-async", daemon=True)
        self.thread.start()
        self.scheduler = None
        self.state = None
        self.router = None
        self.call(self._initialize())
        if self._pending_gemini_key:
            try:
                self.call(self.activate_gemini(self._pending_gemini_key), timeout=90)
            except Exception as exc:
                self.gemini_validation_error = f"{type(exc).__name__}: {exc}"
                self.provider_mode = "gemini-validation-failed"
            finally:
                self._pending_gemini_key = None

    def _run_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def call(self, coro, timeout: float = 180.0):
        fut = asyncio.run_coroutine_threadsafe(coro, self.loop)
        return fut.result(timeout=timeout)

    def _router(self):
        if not self.execution_enabled:
            return None
        transport = self.GeminiInteractionsTransport(api_key=self.gemini_key, model=self.gemini_model or "auto")
        provider = self.AIWorkerProvider(transport)
        return self.MultiProviderRouter([provider])

    async def _initialize(self):
        active = self.projects.active_project_id()
        if active:
            try:
                store = self.projects.store(active)
                state = store.load()
            except Exception:
                state = None
            if state is not None:
                state = store.prepare_for_resume(state)
                self.state = state
                self.device_fabric.initialize_windows(state)
                # Migrate prior real-work projects away from the old "finite batch ==
                # whole goal complete" semantics.  A persisted premature completion is
                # reopened unless it has an explicit goal-audit proof.
                state.metadata.setdefault("require_goal_audit", True)
                state.metadata.setdefault("strict_goal_completion_gate", True)
                state.metadata.setdefault("min_goal_audit_evidence_refs", 3)
                state.metadata.setdefault("min_goal_audit_grounded_refs", 2)
                state.metadata.setdefault("min_goal_continuity_generations", 3)
                if not (state.goal_success_definition or "").strip():
                    state.goal_success_definition = (
                        "The locked objective is complete only when concrete implementation or deliverable evidence exists, "
                        "independent verification supports it, no blocking work remains, and the strict goal audit passes."
                    )
                lower_goal = (state.goal or "").lower()
                if ("ceo" in lower_goal) and any(token in lower_goal for token in ("autónom", "autonom", "uso diario", "continuamente", "trabajador autónomo")):
                    state.metadata.setdefault("requires_field_endurance_certification", True)
                    state.metadata.setdefault("field_endurance_certified", False)
                migration = self.goal_completion_gate.migrate_invalid_legacy_pass(state)
                if state.completed_at is not None and not state.metadata.get("goal_audit_passed"):
                    state.metadata["reopened_after_goal_continuity_fix"] = True
                    state.completed_at = None
                    migration = {"changed": True, "reason": "premature_completion_reopened"}
                if migration.get("changed"):
                    state.metadata["grounded_completion_gate_migration"] = migration
                    store.save(state)
                    self.projects.touch(state)
                if self.execution_enabled and not state.completed_at:
                    self.router = self._router()
                    self.scheduler = self.ContinuousScheduler(state, None, store, graph=self.Graph(), router=self.router)
                    self.scheduler.start()
        return True

    async def _stop_scheduler(self):
        if self.scheduler is not None:
            await self.scheduler.stop()
            self.projects.touch(self.scheduler.state)
            self.state = self.scheduler.state
            self.scheduler = None

    async def start_project(self, body: dict[str, Any]):
        if not self.execution_enabled:
            raise RuntimeError("Gemini no está validado. Actívalo primero; no se creará un proyecto que parezca estar trabajando cuando está pausado.")
        await self._stop_scheduler()
        goal_text = str(body.get("goal") or "").strip()
        if len(goal_text) < 3:
            raise ValueError("El objetivo debe tener al menos 3 caracteres")
        goal = self.GoalEngine().lock(
            goal_text,
            constraints=[
                "No spending, purchases, subscriptions or credits without separate explicit human approval.",
                "No automatic promotion of candidate builds.",
                "No Git network actions without explicit authorization.",
                "Destructive actions require a human gate.",
            ],
            forbidden_actions=["automatic_spending", "automatic_candidate_promotion", "unauthorized_git_network", "ungated_destructive_action"],
            urgency=50,
            budget_limit=0.0,
        )
        planner = self.BaselineTaskPlanner(self.TaskDecomposer())
        state = await planner.plan(goal)
        self.GoalEngine().apply(state, goal)
        if not (state.goal_success_definition or "").strip():
            state.goal_success_definition = (
                "The locked objective is complete only when concrete implementation or deliverable evidence exists, "
                "independent verification supports it, no blocking work remains, and the strict goal audit passes."
            )
        state.project_name = str(body.get("name") or goal_text[:80]).strip()
        state.power_percent = max(1, min(100, int(body.get("power_percent") or 30)))
        state.metadata["real_work_intake_v1"] = {
            "mode": "general_supervised",
            "automatic_spending": False,
            "automatic_candidate_promotion": False,
            "git_network_allowed": False,
            "destructive_actions_require_gate": True,
            "created_via": "stdlib_goal_engine",
        }
        state.metadata["production_verified"] = False
        self.device_fabric.initialize_windows(state)
        self.device_fabric.rebalance(state)
        state.metadata["provider_mode"] = self.provider_mode
        state.metadata["require_goal_audit"] = True
        state.metadata["goal_audit_passed"] = False
        state.metadata["goal_continuity_generation"] = 0
        state.metadata["strict_goal_completion_gate"] = True
        state.metadata["min_goal_audit_evidence_refs"] = 3
        state.metadata["min_goal_audit_grounded_refs"] = 2
        state.metadata["min_goal_continuity_generations"] = 3
        lower_goal = goal_text.lower()
        if ("ceo" in lower_goal) and any(token in lower_goal for token in ("autónom", "autonom", "uso diario", "continuamente", "trabajador autónomo")):
            state.metadata["requires_field_endurance_certification"] = True
            state.metadata.setdefault("field_endurance_certified", False)
        if not self.execution_enabled:
            state.paused = True
            state.metadata["execution_disabled_reason"] = "Gemini API key was not provided for this session"
        store = self.projects.store(state.id)
        store.save(state)
        self.projects.register(state, make_active=True)
        self.state = state
        if self.execution_enabled:
            self.router = self._router()
            self.scheduler = self.ContinuousScheduler(state, None, store, graph=self.Graph(), router=self.router)
            self.scheduler.start()
        return await self.snapshot()

    async def activate_gemini(self, raw_key: str):
        # Do not trust formatting alone. Accept a plausible opaque credential and
        # prove it against Gemini before announcing that execution is enabled.
        key = _normalize_gemini_key(raw_key)
        if not key:
            candidate = str(raw_key or "").strip().strip("\"'").strip()
            if 20 <= len(candidate) <= 256 and not any(ch.isspace() for ch in candidate):
                key = candidate
        if not key:
            raise ValueError("No se reconoció una API key válida. La clave permanece en el campo para que puedas corregirla.")

        transport = self.GeminiInteractionsTransport(api_key=key, model="auto")
        probe = await transport.probe_live()
        if not probe.get("ok"):
            detail = str(probe.get("detail") or probe.get("status") or "validación fallida")
            detail = detail.replace(key, "<redacted-api-key>")[:700]
            raise RuntimeError(f"Gemini rechazó o no pudo validar la clave: {detail}")

        # Only after a real provider probe succeeds do we switch the session to
        # execution mode. The credential is never persisted by CEO.
        self.gemini_key = key
        self.execution_enabled = True
        self.gemini_model = str(probe.get("model") or "") or None
        self.provider_mode = "gemini-live-verified"
        state = self._state_obj()
        if state is not None:
            state.metadata["provider_mode"] = self.provider_mode
            state.metadata["gemini_live_verified"] = True
            if self.gemini_model:
                state.metadata["gemini_model"] = self.gemini_model
            state.metadata.pop("execution_disabled_reason", None)
            state.metadata.setdefault("require_goal_audit", True)
            state.metadata.setdefault("strict_goal_completion_gate", True)
            state.metadata.setdefault("min_goal_audit_evidence_refs", 3)
            state.metadata.setdefault("min_goal_audit_grounded_refs", 2)
            state.metadata.setdefault("min_goal_continuity_generations", 3)
            if not (state.goal_success_definition or "").strip():
                state.goal_success_definition = (
                    "The locked objective is complete only when concrete implementation or deliverable evidence exists, "
                    "independent verification supports it, no blocking work remains, and the strict goal audit passes."
                )
            lower_goal = (state.goal or "").lower()
            if ("ceo" in lower_goal) and any(token in lower_goal for token in ("autónom", "autonom", "uso diario", "continuamente", "trabajador autónomo")):
                state.metadata.setdefault("requires_field_endurance_certification", True)
                state.metadata.setdefault("field_endurance_certified", False)
            migration = self.goal_completion_gate.migrate_invalid_legacy_pass(state)
            if state.completed_at is not None and not state.metadata.get("goal_audit_passed"):
                state.metadata["reopened_after_goal_continuity_fix"] = True
                state.completed_at = None
            if migration.get("changed"):
                state.metadata["grounded_completion_gate_migration"] = migration
            state.paused = False
            store = self.projects.store(state.id)
            store.save(state)
            self.projects.touch(state)
            if self.scheduler is None and not state.completed_at:
                self.router = self._router()
                self.scheduler = self.ContinuousScheduler(state, None, store, graph=self.Graph(), router=self.router)
                self.scheduler.start()
        return await self.snapshot()

    async def _ensure_scheduler_health(self):
        state = self._state_obj()
        if state is None or not self.execution_enabled or state.paused or state.completed_at is not None:
            return
        if self.scheduler is not None:
            runner = getattr(self.scheduler, "_runner", None)
            if runner is not None and runner.done():
                error = None
                try:
                    error = runner.exception()
                except Exception as exc:
                    error = exc
                if error is not None:
                    state.metadata.setdefault("scheduler_crash_history", []).append({
                        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
                        "error": f"{type(error).__name__}: {error}"[:1000],
                    })
                    state.metadata["scheduler_crash_history"] = state.metadata["scheduler_crash_history"][-20:]
                self.scheduler = None
        if self.scheduler is None:
            store = self.projects.store(state.id)
            self.router = self._router()
            self.scheduler = self.ContinuousScheduler(state, None, store, graph=self.Graph(), router=self.router)
            self.scheduler.start()
            state.metadata["scheduler_auto_restarts"] = int(state.metadata.get("scheduler_auto_restarts", 0)) + 1
            store.save(state)

    def _state_obj(self):
        return self.scheduler.state if self.scheduler is not None else self.state

    async def snapshot(self):
        await self._ensure_scheduler_health()
        state = self._state_obj()
        if state is None:
            return {
                "active": False,
                "execution_enabled": self.execution_enabled,
                "provider_mode": self.provider_mode,
                "gemini_model": self.gemini_model,
                "power_percent": 30,
                "paused": False,
                "metrics": {"progress": 0, "running": 0, "completed": 0, "pending": 0},
                "queue": [],
                "observability": {"health":{"level":"idle","reasons":["no active project"]},"current_work":[],"next_work":[],"throughput":{},"eta":{"seconds":0},"attention":[],"stale_workers":[],"timeline":[],"scheduler":{"alive":False,"auto_restarts":0},"resilience":{"worker_recoveries":0,"adaptive_scheduler":{}}},
                "attention_cards": [],
                "message": "Goal Engine listo para recibir un objetivo.",
            }
        leaves = list(state.leaf_tasks)
        statuses = [t.status.value for t in leaves]
        queue = []
        for t in sorted(leaves, key=lambda x: (-int(x.priority), x.created_at))[:100]:
            if t.status.value not in {"complete", "superseded"}:
                queue.append({
                    "id": t.id, "title": t.title, "status": t.status.value, "priority": t.priority,
                    "dependencies": list(t.dependencies), "provider": t.provider_name,
                })
        try:
            self.projects.touch(state)
        except Exception:
            pass
        runner = getattr(self.scheduler, "_runner", None) if self.scheduler is not None else None
        scheduler_alive = bool(runner is not None and not runner.done())
        scheduler_error = None
        if runner is not None and runner.done():
            try:
                exc = runner.exception()
                if exc is not None:
                    scheduler_error = f"{type(exc).__name__}: {exc}"[:800]
            except Exception as exc:
                scheduler_error = f"{type(exc).__name__}: {exc}"[:800]
        if self.scheduler is not None:
            operational_status = self.scheduler.operational_status()
        elif state.completed_at is not None:
            operational_status = "COMPLETADO"
        elif state.paused:
            operational_status = "PAUSADO"
        else:
            operational_status = "SIN SCHEDULER"
        progress = self.progress_tracker.snapshot(state, persist=True)
        self.device_fabric.initialize_windows(state)
        device_plan = self.device_fabric.rebalance(state)
        timeline = list(state.metadata.get("activity_timeline", []))[-12:]
        watchdog = (state.metadata.get("autonomous_loop") or {}).get("watchdog") or {}
        stalled = state.metadata.get("autonomy_stalled")
        message = (
            f"Scheduler {operational_status}."
            + (f" Watchdog: {watchdog.get('status')}." if watchdog else "")
            + (f" ERROR: {scheduler_error}" if scheduler_error else "")
        )
        return {
            "active": True,
            "project_id": state.id,
            "project_name": state.project_name or state.goal[:80],
            "goal": state.goal,
            "execution_enabled": self.execution_enabled,
            "provider_mode": self.provider_mode,
            "gemini_model": self.gemini_model,
            "power_percent": state.power_percent,
            "paused": state.paused,
            "completed_at": state.completed_at,
            "scheduler_alive": scheduler_alive,
            "scheduler_error": scheduler_error,
            "operational_status": operational_status,
            "watchdog": watchdog,
            "autonomy_stalled": stalled,
            "goal_audit_passed": bool(state.metadata.get("goal_audit_passed", False)),
            "goal_continuity_generation": int(state.metadata.get("goal_continuity_generation", 0)),
            "continuity_duplicate_spawn_drops": int(state.metadata.get("continuity_duplicate_spawn_drops", 0)),
            "continuity_nonspawn_rejections": int(state.metadata.get("continuity_nonspawn_rejections", 0)),
            "goal_audit_rejection": state.metadata.get("last_goal_audit_rejection"),
            "goal_audit_invalidated": state.metadata.get("goal_audit_invalidated"),
            "field_endurance_required": bool(state.metadata.get("requires_field_endurance_certification", False)),
            "field_endurance_certified": bool(state.metadata.get("field_endurance_certified", False)),
            "metrics": {
                "progress": progress["display_progress"],
                "batch_progress": progress["batch_progress"],
                "legacy_progress": int(round(state.progress)),
                "running": progress["productive_running"],
                "completed": progress["productive_completed"],
                "pending": progress["productive_pending"],
                "control_running": progress["control_running"],
                "control_pending": progress["control_pending"],
                "control_completed": progress["control_completed"],
                "last_productive_progress_at": progress["last_productive_progress_at"],
                "superseded": statuses.count("superseded"),
            },
            "device_fabric": {
                "plan": device_plan,
                "notification_target": self.device_fabric.notification_target(state),
            },
            "queue": queue,
            "recent_activity": timeline,
            "observability": self.observability.snapshot(state, self.scheduler),
            "attention_cards": self.attention_broker.cards(state),
            "remote_control": {"protocol_version": self.remote_protocol.PROTOCOL_VERSION, "paired_devices": len(state.metadata.get("paired_remote_devices", {}) or {}), "network_exposed": False, "mutation_nonce_required": True, "replay_guard": "remote_session_v2"},
            "message": message,
        }

    async def attention_action(self, body: dict[str, Any]):
        state = self._state_obj()
        if state is None:
            raise RuntimeError("No active project")
        result = self.attention_broker.act(state, str(body.get("id") or ""), str(body.get("action") or ""), selection=body.get("selection"))
        store = self.scheduler.store if self.scheduler is not None else self.projects.store(state.id)
        store.save(state); self.projects.touch(state)
        return await self.snapshot()

    async def remote_pair(self, body: dict[str, Any]):
        if body.get("confirm") is not True:
            raise PermissionError("Remote pairing requires explicit local human confirmation")
        state = self._state_obj()
        if state is None:
            raise RuntimeError("No active project")
        device_id = str(body.get("device_id") or "").strip()
        if not device_id:
            raise ValueError("device_id required")
        scopes = [str(x) for x in (body.get("scopes") or ["status:read", "attention:read", "project:pause", "project:power", "decision:act"])]
        receipt = self.remote_protocol.pair(state, device_id, scopes)
        tokens = {scope: self.remote_protocol.issue_token(device_id, scope, ttl_seconds=3600) for scope in receipt.scopes}
        store = self.scheduler.store if self.scheduler is not None else self.projects.store(state.id)
        store.save(state); self.projects.touch(state)
        return {"paired": True, "receipt": receipt.to_dict(), "tokens": tokens, "safety": {"spending": False, "publication": False, "arbitrary_commands": False}}

    async def remote_status(self, token: str):
        state = self._state_obj()
        if state is None:
            raise RuntimeError("No active project")
        if self.remote_protocol.verify_token(state, token, "status:read") is None:
            raise PermissionError("Invalid or expired remote token")
        return self.remote_protocol.status_payload(state, self.observability.snapshot(state, self.scheduler))

    async def remote_attention(self, token: str):
        state = self._state_obj()
        if state is None:
            raise RuntimeError("No active project")
        if self.remote_protocol.verify_token(state, token, "attention:read") is None:
            raise PermissionError("Invalid or expired remote token")
        return {"attention": self.attention_broker.cards(state)}

    async def remote_decision_action(self, token: str, body: dict[str, Any]):
        state = self._state_obj()
        if state is None:
            raise RuntimeError("No active project")
        receipt = self.remote_session_guard.verify_and_consume(self.remote_protocol, state, token, "decision:act", str(body.get("nonce") or ""))
        if not receipt.accepted:
            raise PermissionError(f"Remote mutation rejected: {receipt.reason}")
        result = self.attention_broker.act(state, str(body.get("id") or ""), str(body.get("action") or ""), selection=body.get("selection"))
        store = self.scheduler.store if self.scheduler is not None else self.projects.store(state.id)
        store.save(state); self.projects.touch(state)
        return {"result": result, "attention": self.attention_broker.cards(state)}

    async def remote_pause(self, token: str, body: dict[str, Any]):
        state = self._state_obj()
        if state is None:
            raise RuntimeError("No active project")
        receipt = self.remote_session_guard.verify_and_consume(self.remote_protocol, state, token, "project:pause", str(body.get("nonce") or ""))
        if not receipt.accepted:
            raise PermissionError(f"Remote mutation rejected: {receipt.reason}")
        paused = body.get("paused")
        if not isinstance(paused, bool):
            raise ValueError("paused must be a boolean")
        return await self.pause(paused)

    async def remote_power(self, token: str, body: dict[str, Any]):
        state = self._state_obj()
        if state is None:
            raise RuntimeError("No active project")
        receipt = self.remote_session_guard.verify_and_consume(self.remote_protocol, state, token, "project:power", str(body.get("nonce") or ""))
        if not receipt.accepted:
            raise PermissionError(f"Remote mutation rejected: {receipt.reason}")
        if "power_percent" not in body:
            raise ValueError("power_percent required")
        return await self.power(int(body["power_percent"]))

    async def pause(self, paused: bool):
        state = self._state_obj()
        if state is None:
            return await self.snapshot()
        state.paused = bool(paused)
        if self.scheduler is not None:
            self.scheduler.store.save(state)
        else:
            self.projects.store(state.id).save(state)
        self.projects.touch(state)
        return await self.snapshot()

    async def power(self, value: int):
        state = self._state_obj()
        if state is not None:
            state.power_percent = max(1, min(100, int(value)))
            self.device_fabric.rebalance(state)
            if self.scheduler is not None:
                self.scheduler.store.save(state)
            else:
                self.projects.store(state.id).save(state)
            self.projects.touch(state)
        return await self.snapshot()

    async def activate_project(self, project_id: str):
        project_id = str(project_id or "").strip()
        if not project_id:
            raise ValueError("project_id requerido")
        await self._stop_scheduler()
        store = self.projects.store(project_id)
        state = store.load()
        if state is None:
            raise KeyError(project_id)
        state = store.prepare_for_resume(state)
        self.projects.set_active(project_id)
        state.metadata.setdefault("require_goal_audit", True)
        state.metadata.setdefault("strict_goal_completion_gate", True)
        state.metadata.setdefault("min_goal_audit_evidence_refs", 3)
        state.metadata.setdefault("min_goal_audit_grounded_refs", 2)
        state.metadata.setdefault("min_goal_continuity_generations", 3)
        if not (state.goal_success_definition or "").strip():
            state.goal_success_definition = (
                "The locked objective is complete only when concrete implementation or deliverable evidence exists, "
                "independent verification supports it, no blocking work remains, and the strict goal audit passes."
            )
        lower_goal = (state.goal or "").lower()
        if ("ceo" in lower_goal) and any(token in lower_goal for token in ("autónom", "autonom", "uso diario", "continuamente", "trabajador autónomo")):
            state.metadata.setdefault("requires_field_endurance_certification", True)
            state.metadata.setdefault("field_endurance_certified", False)
        migration = self.goal_completion_gate.migrate_invalid_legacy_pass(state)
        if migration.get("changed"):
            state.metadata["grounded_completion_gate_migration"] = migration
        # DEV20 migration: older builds could loop through hundreds of continuity
        # audits whose follow-ups were subsequently deduplicated.  If we reopen such
        # a project with no productive work queued, prime the existing deterministic
        # gap bridge so the next duplicate-only audit immediately returns to real work.
        generation = int(state.metadata.get("goal_continuity_generation", 0) or 0)
        productive_open = [
            t for t in state.leaf_tasks
            if not (t.metadata.get("goal_continuity_audit") or t.metadata.get("autonomy_recovery") or t.metadata.get("control_plane_atomic") or t.metadata.get("continuity_control"))
            and t.status.value not in {"complete", "partial_complete", "complete_with_uncertainty", "superseded", "failed"}
        ]
        if generation >= 8 and not productive_open:
            state.metadata["continuity_nonspawn_rejections"] = max(
                2, int(state.metadata.get("continuity_nonspawn_rejections", 0) or 0)
            )
            state.metadata["dev20_churn_breaker_primed"] = True
        state.paused = not self.execution_enabled
        store.save(state)
        self.projects.touch(state)
        self.state = state
        if self.execution_enabled and state.completed_at is None:
            self.router = self._router()
            self.scheduler = self.ContinuousScheduler(state, None, store, graph=self.Graph(), router=self.router)
            self.scheduler.start()
        return await self.snapshot()

    async def projects_list(self):
        return self.projects.portfolio_list(include_archived=True, total_slots=8)

    async def update_status(self, remote: bool = False):
        return await asyncio.to_thread(self.updater.status, current_version=APP_VERSION, include_remote=bool(remote))

    async def update_config(self, payload: dict[str, Any]):
        return await asyncio.to_thread(
            self.updater.save_config,
            manifest_url=str(payload.get("manifest_url") or ""),
            channel=str(payload.get("channel") or "stable"),
            auto_check=bool(payload.get("auto_check", True)),
        )

    async def update_stage(self):
        return await asyncio.to_thread(self.updater.stage_latest, current_version=APP_VERSION)

    async def update_activate(self, version: str):
        return await asyncio.to_thread(self.updater.activate, version)

    async def shutdown(self):
        try:
            await self._stop_scheduler()
        finally:
            self.loop.call_soon(self.loop.stop)


class Handler(BaseHTTPRequestHandler):
    engine: CEOEngine

    def log_message(self, fmt, *args):
        try:
            (RESULTS / "CEO_STDLIB_SERVER.log").open("a", encoding="utf-8").write((fmt % args) + "\n")
        except Exception:
            pass

    def _send(self, code: int, data: bytes, content_type: str):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def json(self, obj: Any, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"), "application/json; charset=utf-8")

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw.decode("utf-8") or "{}")

    def bearer(self) -> str:
        value = str(self.headers.get("Authorization") or "")
        return value[7:].strip() if value.lower().startswith("bearer ") else ""

    def do_GET(self):
        try:
            path = urllib.parse.urlparse(self.path).path
            if path == "/":
                return self._send(200, HTML.encode("utf-8"), "text/html; charset=utf-8")
            if path == "/favicon.ico":
                icon = ROOT / "assets" / "CEO_DE_IAS.ico"
                if icon.is_file():
                    return self._send(200, icon.read_bytes(), "image/x-icon")
                return self._send(204, b"", "image/x-icon")
            if path == "/api/health":
                pointer = self.engine.updater.current_pointer() or {}
                storage_ready = bool(self.engine.projects.root.exists())
                core_ready = bool(self.engine.loop.is_running() and self.engine.thread.is_alive())
                frontend_ready = bool(HTML and "Goal Engine" in HTML and "/api/state" in HTML)
                ready = bool(storage_ready and core_ready and frontend_ready)
                return self.json({
                    "ok": ready,
                    "ready": ready,
                    "version": APP_VERSION,
                    "activation_id": pointer.get("activation_id"),
                    "provider_mode": self.engine.provider_mode,
                    "execution_enabled": self.engine.execution_enabled,
                    "storage_ready": storage_ready,
                    "scheduler_component_ready": core_ready,
                    "frontend_ready": frontend_ready,
                }, 200 if ready else 503)
            if path == "/api/state":
                return self.json(self.engine.call(self.engine.snapshot()))
            if path == "/api/projects":
                return self.json(self.engine.call(self.engine.projects_list()))
            if path == "/api/update/status":
                query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                remote = str((query.get("remote") or ["0"])[0]).lower() in {"1","true","yes"}
                return self.json(self.engine.call(self.engine.update_status(remote), timeout=60))
            if path == "/api/work-queue":
                s = self.engine.call(self.engine.snapshot())
                return self.json({"active": s.get("active", False), "queue": s.get("queue", []), "safety": {"automatic_spending": False, "automatic_candidate_promotion": False, "git_network_allowed": False, "destructive_actions_require_gate": True}})
            if path == "/api/operations":
                s = self.engine.call(self.engine.snapshot())
                return self.json({"active": s.get("active", False), "project_id": s.get("project_id"), "observability": s.get("observability", {})})
            if path == "/api/attention":
                s = self.engine.call(self.engine.snapshot())
                return self.json({"attention": s.get("attention_cards", [])})
            if path == "/api/remote/status":
                return self.json(self.engine.call(self.engine.remote_status(self.bearer())))
            if path == "/api/remote/attention":
                return self.json(self.engine.call(self.engine.remote_attention(self.bearer())))
            return self.json({"error": "not_found"}, 404)
        except Exception as exc:
            return self.json({"error": str(exc)}, 500)

    def do_POST(self):
        try:
            path = urllib.parse.urlparse(self.path).path
            if path == "/api/start":
                return self.json(self.engine.call(self.engine.start_project(self.body()), timeout=240))
            if path == "/api/pause":
                return self.json(self.engine.call(self.engine.pause(True)))
            if path == "/api/resume":
                if not self.engine.execution_enabled:
                    return self.json({"error": "Gemini no está validado en esta sesión. Actívalo desde la interfaz antes de reanudar."}, 409)
                return self.json(self.engine.call(self.engine.pause(False)))
            if path == "/api/power":
                return self.json(self.engine.call(self.engine.power(int(self.body().get("power_percent") or 30))))
            if path == "/api/session-key":
                body = self.body()
                return self.json(self.engine.call(self.engine.activate_gemini(str(body.get("key") or ""))))
            if path == "/api/project/activate":
                body = self.body()
                return self.json(self.engine.call(self.engine.activate_project(str(body.get("project_id") or "")), timeout=120))
            if path == "/api/attention/action":
                return self.json(self.engine.call(self.engine.attention_action(self.body())))
            if path == "/api/remote/pair":
                body = self.body()
                if body.get("confirm") is not True:
                    return self.json({"error": "Remote pairing requires explicit local human confirmation."}, 409)
                return self.json(self.engine.call(self.engine.remote_pair(body)))
            if path == "/api/remote/decision":
                return self.json(self.engine.call(self.engine.remote_decision_action(self.bearer(), self.body())))
            if path == "/api/remote/pause":
                return self.json(self.engine.call(self.engine.remote_pause(self.bearer(), self.body())))
            if path == "/api/remote/power":
                return self.json(self.engine.call(self.engine.remote_power(self.bearer(), self.body())))
            if path == "/api/update/config":
                return self.json(self.engine.call(self.engine.update_config(self.body()), timeout=30))
            if path == "/api/update/stage":
                return self.json(self.engine.call(self.engine.update_stage(), timeout=240))
            if path == "/api/update/install":
                body = self.body()
                if body.get("confirm") is not True:
                    return self.json({"error": "La instalación requiere confirmación humana explícita."}, 409)
                version = str(body.get("version") or "")
                result = self.engine.call(self.engine.update_activate(version), timeout=30)
                launcher = str(result.get("launcher_path") or "")
                activation_id = str(result.get("activation_id") or "")
                helper = ROOT / "scripts" / "relaunch_after_update.py"
                subprocess.Popen(
                    [
                        sys.executable, str(helper),
                        "--wait-pid", str(os.getpid()),
                        "--launcher", launcher,
                        "--data-root", str(self.engine.data_dir),
                        "--version", version,
                        "--activation-id", activation_id,
                        "--fallback-launcher", str(ROOT / "ABRIR_CEO.cmd"),
                        "--health-timeout", "60",
                    ],
                    cwd=str(ROOT),
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                )
                self.json({
                    "status": "RESTARTING_PENDING_HEALTH",
                    "version": version,
                    "activation_id": activation_id,
                    "automatic_promotion": False,
                    "human_confirmed": True,
                    "rollback_armed": True,
                })
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return self.json({"error": "not_found"}, 404)
        except Exception as exc:
            return self.json({"error": str(exc)}, 500)


def free_port() -> int:
    for port in range(8765, 8781):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("No hay un puerto local libre entre 8765 y 8780")


def open_browser(url: str) -> str:
    if os.name == "nt":
        candidates = [
            Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe",
            Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
            Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Microsoft/Edge/Application/msedge.exe",
            Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft/Edge/Application/msedge.exe",
        ]
        for exe in candidates:
            try:
                if exe.is_file():
                    subprocess.Popen([str(exe), f"--app={url}", "--start-maximized"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return str(exe)
            except Exception:
                pass
    webbrowser.open(url, new=1)
    return "default-browser"


def _normalize_gemini_key(raw: str | None) -> str | None:
    """Extract one plausible Gemini/Google API key without logging it.

    Clipboard content can contain CR/LF, quotes, labels, rich-text fallbacks or
    zero-width Unicode characters.  Search *within* the text instead of requiring
    the clipboard to contain only the key.  Never return surrounding content.
    """
    if raw is None:
        return None
    text = str(raw)
    # Remove common invisible formatting characters that can be introduced when
    # copying from browsers/password managers while keeping the actual key intact.
    text = text.translate({ord(ch): None for ch in "\u200b\u200c\u200d\ufeff\u2060"})
    # Google API keys used by Gemini normally begin with AIza.  Keep the pattern
    # narrow enough to avoid treating arbitrary clipboard text as a credential.
    matches = re.findall(r"(?<![0-9A-Za-z_-])(AIza[0-9A-Za-z_-]{24,80})(?![0-9A-Za-z_-])", text)
    if len(matches) == 1:
        return matches[0]
    # Also accept an exact key if boundary characters were unusual.
    candidate = text.strip().strip("\"'").strip()
    if re.fullmatch(r"AIza[0-9A-Za-z_-]{24,80}", candidate):
        return candidate
    return None


def _read_windows_clipboard_native() -> str | None:
    """Read CF_UNICODETEXT directly via Win32, with no third-party dependency."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        CF_UNICODETEXT = 13
        user32.OpenClipboard.argtypes = [wintypes.HWND]
        user32.OpenClipboard.restype = wintypes.BOOL
        user32.GetClipboardData.argtypes = [wintypes.UINT]
        user32.GetClipboardData.restype = wintypes.HANDLE
        user32.IsClipboardFormatAvailable.argtypes = [wintypes.UINT]
        user32.IsClipboardFormatAvailable.restype = wintypes.BOOL
        kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
        kernel32.GlobalLock.restype = wintypes.LPVOID
        kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        kernel32.GlobalUnlock.restype = wintypes.BOOL
        if not user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
            return None
        opened = False
        for _ in range(10):
            if user32.OpenClipboard(None):
                opened = True
                break
            time.sleep(0.05)
        if not opened:
            return None
        try:
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return None
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return None
            try:
                return ctypes.wstring_at(ptr)
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()
    except Exception:
        return None


def _read_windows_clipboard_powershell() -> str | None:
    """Fallback clipboard reader for Windows PowerShell/PowerShell 7."""
    if sys.platform != "win32":
        return None
    ps = shutil.which("powershell.exe") or shutil.which("pwsh.exe") or shutil.which("powershell")
    if not ps:
        return None
    commands = [
        "$v=Get-Clipboard -Raw -ErrorAction Stop; if($null -ne $v){[Console]::Out.Write($v)}",
        "$v=Get-Clipboard -ErrorAction Stop; if($null -ne $v){[Console]::Out.Write(($v -join [Environment]::NewLine))}",
    ]
    for command in commands:
        try:
            cp = subprocess.run(
                [ps, "-NoProfile", "-NonInteractive", "-Command", command],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if cp.returncode == 0 and cp.stdout:
                return cp.stdout
        except Exception:
            pass
    return None


def _read_windows_clipboard_gemini_key() -> str | None:
    """Try native Win32 first, then PowerShell; return only the extracted key."""
    for reader in (_read_windows_clipboard_native, _read_windows_clipboard_powershell):
        try:
            key = _normalize_gemini_key(reader())
            if key:
                return key
        except Exception:
            pass
    return None


def _gui_gemini_key_prompt() -> str | None:
    """Last-resort GUI paste box. Text is never persisted and the field is masked."""
    if sys.platform != "win32":
        return None
    try:
        import tkinter as tk
        root = tk.Tk()
        root.title("CEO de IAs - Gemini API key")
        root.geometry("560x180")
        root.resizable(False, False)
        tk.Label(root, text="No pude leer la clave del portapapeles automáticamente.", pady=10).pack()
        tk.Label(root, text="Pégala aquí con Ctrl+V. No se guardará en disco.").pack()
        value = tk.StringVar()
        entry = tk.Entry(root, textvariable=value, show="*", width=70)
        entry.pack(padx=18, pady=12)
        entry.focus_force()
        result = {"key": None}
        def accept(event=None):
            result["key"] = _normalize_gemini_key(value.get())
            root.destroy()
        def cancel(event=None):
            root.destroy()
        buttons = tk.Frame(root)
        buttons.pack()
        tk.Button(buttons, text="Usar clave", command=accept, width=16).pack(side=tk.LEFT, padx=6)
        tk.Button(buttons, text="Continuar sin Gemini", command=cancel, width=20).pack(side=tk.LEFT, padx=6)
        root.bind("<Return>", accept)
        root.bind("<Escape>", cancel)
        root.mainloop()
        return result["key"]
    except Exception:
        return None


def _wait_startup_health(url: str, *, timeout: float = 12.0) -> dict[str, Any]:
    deadline = time.time() + max(1.0, timeout)
    last_error = "startup health unavailable"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url.rstrip("/") + "/api/health", timeout=1.5) as resp:
                payload = json.loads(resp.read(1024 * 1024).decode("utf-8"))
            if (
                isinstance(payload, dict)
                and payload.get("ok") is True
                and payload.get("storage_ready") is True
                and payload.get("scheduler_component_ready") is True
                and payload.get("frontend_ready") is True
            ):
                return payload
            last_error = f"health not ready: {payload}"
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {exc}"
        time.sleep(0.15)
    raise RuntimeError(last_error)


def main() -> int:
    os.chdir(ROOT)
    os.environ["PYTHONPATH"] = str(ROOT) + (os.pathsep + os.environ["PYTHONPATH"] if os.environ.get("PYTHONPATH") else "")
    print("=" * 68)
    print("CEO DE IAs - MODO TRABAJO REAL - SERVIDOR SIN FASTAPI/UVICORN")
    print("=" * 68)
    print("No repite 76-85. No instala dependencias web. No modifica Python global.")
    print("La clave Gemini es temporal y no se guarda en el proyecto.")
    print()
    key = _normalize_gemini_key(os.environ.get("GEMINI_API_KEY"))
    key_source = "environment" if key else None
    key_in_browser = os.getenv("CEO_KEY_IN_BROWSER", "").strip() == "1"
    if not key and not key_in_browser:
        key = _read_windows_clipboard_gemini_key()
        if key:
            key_source = "windows-clipboard"
            print("[OK] Gemini API key detectada automaticamente en el portapapeles.")
            print("[OK] Se usara solo en memoria durante esta sesion; no se imprime ni se guarda.")
    if not key and not key_in_browser:
        print("[INFO] No se detecto automaticamente una Gemini API key valida.")
        print("[INFO] Abriendo un cuadro seguro de pegado como fallback...")
        key = _gui_gemini_key_prompt()
        if key:
            key_source = "gui-paste"
            print("[OK] Gemini API key recibida por cuadro local seguro.")
        else:
            print("[INFO] Se abrira CEO en modo planificacion, sin ejecucion IA real.")
    elif not key and key_in_browser:
        print("[INFO] La interfaz se abrira primero. Activa Gemini desde el campo seguro del navegador local.")
    try:
        engine = CEOEngine(key or None)
        Handler.engine = engine
        port = free_port()
        url = f"http://127.0.0.1:{port}"
        server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        server_thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.4}, name="ceo-stdlib-http", daemon=True)
        server_thread.start()
        startup_health = _wait_startup_health(url)
        shell_integration = None
        if os.name == "nt":
            try:
                from ceo_core.windows_shell import ensure_modern_windows_shell
                shell_integration = ensure_modern_windows_shell(ROOT)
            except Exception as shell_exc:
                shell_integration = {"ok": False, "error": f"{type(shell_exc).__name__}: {shell_exc}"}
        write_status({
            "status": "PASS", "url": url, "port": port, "server": "stdlib-http.server",
            "browser": "pending", "execution_enabled": engine.execution_enabled,
            "provider_mode": engine.provider_mode, "key_source": key_source or "none",
            "results_dir": str(RESULTS), "startup_health": startup_health, "shell_integration": shell_integration,
            "message": "Backend, almacenamiento y frontend listos; navegador pendiente de apertura.",
        })
        browser = open_browser(url)
        write_status({
            "status": "PASS", "url": url, "port": port, "server": "stdlib-http.server",
            "browser": browser, "execution_enabled": engine.execution_enabled,
            "provider_mode": engine.provider_mode, "key_source": key_source or "none",
            "results_dir": str(RESULTS), "startup_health": startup_health, "shell_integration": shell_integration,
            "message": "CEO listo y navegador abierto tras health check local.",
        })
        print(f"\n[OK] CEO abierto: {url}")
        print(f"[OK] Estado: {STATUS_PATH}")
        print(f"[OK] Diagnostico persistente: {DIAGNOSTICS.latest_path}")
        if not engine.execution_enabled:
            print("[AVISO] Sin Gemini: Goal Engine puede planificar y persistir, pero no ejecutara trabajo IA real.")
        print("Mantén esta ventana abierta. Ctrl+C detiene el servidor.")
        try:
            while server_thread.is_alive():
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass
        finally:
            server.shutdown()
            server.server_close()
            server_thread.join(timeout=3)
            try:
                engine.call(engine.shutdown(), timeout=30)
            except Exception:
                pass
        return 0
    except Exception as exc:
        write_failure(exc)
        print(f"\n[BLOCKED] {exc}")
        print(f"Diagnostico garantizado junto al lanzador: {FAILURE_PATH}")
        return 6
    finally:
        os.environ.pop("GEMINI_API_KEY", None)


if __name__ == "__main__":
    raise SystemExit(main())
