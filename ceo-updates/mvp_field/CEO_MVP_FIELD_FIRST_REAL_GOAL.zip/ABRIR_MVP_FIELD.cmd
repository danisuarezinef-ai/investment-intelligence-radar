@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PY="
for %%P in (pythonw.exe python.exe pyw.exe py.exe) do (
  if not defined PY (
    where %%P >nul 2>nul
    if not errorlevel 1 set "PY=%%P"
  )
)

if not defined PY exit /b 7

if /I "%PY%"=="py.exe" (
  start "" /b py.exe -3 scripts\mvp_field_first_real_goal.py
) else if /I "%PY%"=="pyw.exe" (
  start "" /b pyw.exe -3 scripts\mvp_field_first_real_goal.py
) else (
  start "" /b "%PY%" scripts\mvp_field_first_real_goal.py
)
exit /b 0
