Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
cmd = Chr(34) & base & "\ABRIR_MVP_FIELD.cmd" & Chr(34)
sh.Run "cmd.exe /c " & cmd, 0, False
