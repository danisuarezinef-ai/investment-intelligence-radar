CEO de IAs — MVP_FIELD / FIRST_REAL_GOAL

TEMPORARY FIELD BUNDLE. This is NOT an update and does NOT replace the installed CEO.

Double-click:
  MVP_FIELD_PRIMER_OBJETIVO.vbs

What runs:
- one fixed real goal (FIELD-MVP-01)
- one provider only: Gemini
- four normal steps; at most one correction + final verification
- one retry maximum per provider call
- no ContinuousScheduler
- no multi-provider router
- no recovery storm machinery
- no continuity audits
- no updater
- no self-development

Only success metric:
  delivery_pass = true

The final file, if successful, is:
  RESULTADOS_CEO\FIELD_MVP_01.md

Physical field execution is still required. Local/CI qualification cannot mark production ready.
