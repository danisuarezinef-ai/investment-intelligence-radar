from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
from typing import Any

from .models import ProjectState, TaskStatus
from .task_roles_v2 import is_productive
from .continuity_policy import task_for_decision, protected_human_gate


BLOCKING_PRODUCTIVE = {
    TaskStatus.READY,
    TaskStatus.RUNNING,
    TaskStatus.RETRY,
    TaskStatus.WAITING,
    TaskStatus.BLOCKED,
    TaskStatus.FAILED,
    TaskStatus.NEEDS_REVIEW,
}


@dataclass(slots=True)
class DeterministicCompletionCertificate:
    schema_version: int
    project_id: str
    work_complete: bool
    final_complete: bool
    evidence_refs: list[str]
    grounded_refs: list[str]
    blocking_productive_task_ids: list[str]
    non_certification_gaps: list[str]
    pending_certifications: list[str]
    deliverables: dict[str, Any]
    certificate_sha256: str
    issued_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class DeterministicCompletionCertifierV1:
    """Provider-independent completion/certification bridge.

    It can prove that autonomous *work* is finished from durable evidence without
    asking a language model to say PASS. External/field certification remains a
    separate gate and is never fabricated.
    """

    SCHEMA_VERSION = 1
    PENDING_FIELD = "field_endurance_certification_required"

    @staticmethod
    def _open_human_decisions(state: ProjectState) -> list[str]:
        rows: list[str] = []
        for decision in state.decisions.values():
            if getattr(decision.status, "value", decision.status) != "open":
                continue
            task = task_for_decision(state, decision)
            if task is None:
                rows.append(str(decision.id))
                continue
            if is_productive(task, state) or protected_human_gate(task, decision.metadata):
                rows.append(str(decision.id))
        return rows

    @staticmethod
    def _blocking_productive(state: ProjectState) -> list[str]:
        return [
            task.id
            for task in state.leaf_tasks
            if is_productive(task, state) and task.status in BLOCKING_PRODUCTIVE
        ]

    @staticmethod
    def _deliverable_snapshot(state: ProjectState) -> dict[str, Any]:
        rows = state.metadata.get("deliverable_evidence") or {}
        out: dict[str, Any] = {}
        for name in state.goal_deliverables:
            row = rows.get(name)
            if isinstance(row, dict):
                out[name] = {
                    "task_id": str(row.get("task_id") or ""),
                    "sha256": str(row.get("sha256") or ""),
                    "size_bytes": int(row.get("size_bytes") or 0),
                    "ref": str(row.get("ref") or row.get("path") or ""),
                }
            else:
                out[name] = None
        return out

    @staticmethod
    def _hash_payload(payload: dict[str, Any]) -> str:
        canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return sha256(canonical).hexdigest()

    def assess(self, state: ProjectState, goal_gate) -> DeterministicCompletionCertificate:
        refs = goal_gate.auto_evidence_refs(state)
        verdict = goal_gate.evaluate(state, evidence_refs=refs)

        pending_certifications: list[str] = []
        non_certification_gaps: list[str] = []
        for gap in verdict.gaps:
            text = str(gap)
            if text.startswith("continuity_rounds:"):
                # Continuity rounds are a provider-era control mechanism. The
                # deterministic certificate replaces them when all evidence gates pass.
                continue
            if text == self.PENDING_FIELD:
                pending_certifications.append(text)
                continue
            non_certification_gaps.append(text)

        productive_blockers = self._blocking_productive(state)
        human_decisions = self._open_human_decisions(state)
        if human_decisions:
            non_certification_gaps.append(
                "open_human_decisions:" + ",".join(sorted(human_decisions)[:20])
            )

        work_complete = not non_certification_gaps and not productive_blockers
        final_complete = work_complete and not pending_certifications

        core = {
            "schema_version": self.SCHEMA_VERSION,
            "project_id": state.id,
            "goal": state.goal,
            "work_complete": work_complete,
            "final_complete": final_complete,
            "evidence_refs": list(verdict.evidence_refs),
            "grounded_refs": list(verdict.grounded_refs),
            "blocking_productive_task_ids": list(productive_blockers),
            "non_certification_gaps": list(non_certification_gaps),
            "pending_certifications": list(pending_certifications),
            "deliverables": self._deliverable_snapshot(state),
        }
        digest = self._hash_payload(core)
        return DeterministicCompletionCertificate(
            schema_version=self.SCHEMA_VERSION,
            project_id=state.id,
            work_complete=work_complete,
            final_complete=final_complete,
            evidence_refs=list(verdict.evidence_refs),
            grounded_refs=list(verdict.grounded_refs),
            blocking_productive_task_ids=list(productive_blockers),
            non_certification_gaps=list(non_certification_gaps),
            pending_certifications=list(pending_certifications),
            deliverables=core["deliverables"],
            certificate_sha256=digest,
            issued_at=datetime.now(timezone.utc).isoformat(),
        )

    def apply(self, state: ProjectState, goal_gate) -> dict[str, Any]:
        cert = self.assess(state, goal_gate)
        current = state.metadata.get("deterministic_completion_certificate_v1") or {}
        changed = str(current.get("certificate_sha256") or "") != cert.certificate_sha256

        if not cert.work_complete:
            if state.metadata.get("work_complete_certified_v1"):
                changed = True
            state.metadata["work_complete_certified_v1"] = False
            state.metadata["suppress_goal_continuity_audits_v1"] = False
            if state.metadata.get("goal_audit_evidence", {}).get("source") == "deterministic_completion_certificate_v1":
                state.metadata["goal_audit_passed"] = False
                state.metadata.pop("goal_audit_evidence", None)
            state.metadata["completion_phase_v1"] = "working"
        else:
            state.metadata["work_complete_certified_v1"] = True
            state.metadata["suppress_goal_continuity_audits_v1"] = True
            state.metadata.pop("autonomy_stalled", None)
            state.metadata.pop("operator_block_reason", None)

            retired: list[str] = []
            for task in state.leaf_tasks:
                if not task.metadata.get("goal_continuity_audit"):
                    continue
                if task.status in {
                    TaskStatus.READY, TaskStatus.RETRY, TaskStatus.WAITING,
                    TaskStatus.BLOCKED, TaskStatus.NEEDS_REVIEW, TaskStatus.FAILED,
                }:
                    task.status = TaskStatus.SUPERSEDED
                    task.worker_id = None
                    task.metadata["superseded_reason"] = "deterministic_completion_certificate_replaced_provider_audit"
                    retired.append(task.id)
            if retired:
                state.metadata["deterministic_completion_retired_audits_v1"] = retired[-50:]
                changed = True

            if cert.pending_certifications:
                state.metadata["completion_phase_v1"] = "work_complete_pending_certification"
                state.metadata["operator_productivity_state"] = "CERTIFICACIÓN PENDIENTE"
                state.metadata["goal_audit_passed"] = False
            else:
                state.metadata["completion_phase_v1"] = "deterministically_certified"
                state.metadata["operator_productivity_state"] = "COMPLETADO"
                state.metadata["goal_audit_passed"] = True
                state.metadata["goal_audit_evidence"] = {
                    "source": "deterministic_completion_certificate_v1",
                    "certificate_sha256": cert.certificate_sha256,
                    "verified_at": cert.issued_at,
                    "evidence_refs": list(cert.evidence_refs),
                    "grounded_refs": list(cert.grounded_refs),
                }
                supporting = (cert.grounded_refs or cert.evidence_refs)
                supporting_task = supporting[0] if supporting else None
                completion_evidence = state.metadata.setdefault("completion_evidence", {})
                for criterion in state.completion_criteria:
                    completion_evidence[criterion] = {
                        "task_id": supporting_task,
                        "source": "deterministic_completion_certificate_v1",
                        "evidence_refs": list(cert.evidence_refs),
                        "certificate_sha256": cert.certificate_sha256,
                    }

        if changed:
            state.metadata["deterministic_completion_certificate_v1"] = cert.to_dict()
            state.metadata["deterministic_completion_certificate_updated_at"] = cert.issued_at

        return {
            "changed": bool(changed),
            "work_complete": cert.work_complete,
            "final_complete": cert.final_complete,
            "pending_certifications": list(cert.pending_certifications),
            "non_certification_gaps": list(cert.non_certification_gaps),
            "blocking_productive_task_ids": list(cert.blocking_productive_task_ids),
            "certificate_sha256": cert.certificate_sha256,
        }
